const FONT='"PingFang SC","Microsoft YaHei",system-ui,sans-serif';
export const DOCK_APPS={ios:['ios-phone','ios-safari','wechat','ios-messages'],android:['wechat','alipay','taobao','qq']};
export const ICON_FILES=Object.fromEntries([...new Set(Object.values(DOCK_APPS).flat())].map(name=>[name,`./dock-${name}.jpg`]));
export async function loadDesktopIcons(){const entries=await Promise.all(Object.entries(ICON_FILES).map(async([name,path])=>{const image=new Image();image.src=path;await image.decode();return [name,image];}));return Object.fromEntries(entries);}
function rect(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.stroke();}}
function text(c,value,x,y,size,color,weight=500,align='center'){c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';c.fillText(value,x,y);}
function icon(c,image,x,y,size,platform){if(!image)return;c.save();c.beginPath();c.roundRect(x,y,size,size,size*(platform==='pixel'?.5:.225));c.clip();c.drawImage(image,x,y,size,size);c.restore();}
function status(c,screen,color){
  const {width:w,height:h,platform}=screen,ios=platform==='ios',y=h*.037;
  if(ios){const scale=w/1206,islandW=378*scale,islandH=111*scale,islandY=33*scale;rect(c,(w-islandW)/2,islandY,islandW,islandH,islandH/2,'#030303');c.fillStyle='#11151d';c.beginPath();c.arc(w/2+islandW*.34,islandY+islandH/2,islandH*.105,0,Math.PI*2);c.fill();}
  else{c.fillStyle='#06070a';c.beginPath();c.arc(w/2,h*.025,w*.01,0,Math.PI*2);c.fill();}
  text(c,screen.clock||'13:43',w*(ios?.105:.064),y,w*.041,color,650,'left');
  const start=w*.755,sy=y-w*.017;c.fillStyle=color;
  for(let i=0;i<4;i++)rect(c,start+i*w*.011,sy+w*.027-i*w*.008,w*.007,w*.012+i*w*.008,w*.003,color);
  c.save();c.strokeStyle=color;c.lineCap='round';c.lineWidth=w*.0045;
  for(const radius of [.012,.023,.034]){c.beginPath();c.arc(w*.845,y+w*.011,w*radius,Math.PI*1.23,Math.PI*1.77);c.stroke();}
  c.beginPath();c.arc(w*.845,y+w*.011,w*.003,0,Math.PI*2);c.fill();c.restore();
  c.lineWidth=w*.002;rect(c,w*.891,y-w*.015,w*.059,w*.03,w*.007,null,color);rect(c,w*.954,y-w*.006,w*.004,w*.012,w*.002,color);rect(c,w*.895,y-w*.011,w*.047,w*.022,w*.004,color);
}
function search(c,x,y,w,h,color,fill){rect(c,x,y,w,h,h/2,fill,'#ffffff35');c.save();c.strokeStyle=color;c.lineWidth=h*.055;c.beginPath();c.arc(x+w*.31,y+h*.45,h*.15,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(x+w*.31+h*.1,y+h*.55);c.lineTo(x+w*.31+h*.2,y+h*.65);c.stroke();text(c,'搜索',x+w*.6,y+h*.5,h*.36,color,500);c.restore();}
export function drawDesktop(c,screen,{color='white',underlay=null,icons={}}={}){
  const {width:w,height:h,platform}=screen,ios=platform==='ios';c.save();status(c,screen,color);
  if(ios){
    const x=w*.035,y=h*.866,dw=w*.93,dh=h*.117;
    if(underlay){c.save();c.beginPath();c.roundRect(x,y,dw,dh,w*.085);c.clip();c.filter=`blur(${w*.012}px)`;c.drawImage(underlay,0,0);c.filter='none';c.restore();}
    c.lineWidth=w*.0015;rect(c,x,y,dw,dh,w*.085,'#ffffff2b','#ffffff70');const side=w*.165;
    DOCK_APPS.ios.forEach((name,i)=>icon(c,icons[name],w*(.155+i*.23)-side/2,y+(dh-side)/2,side,platform));search(c,w*.421,h*.815,w*.158,h*.033,color,'#ffffff24');
  }else{
    const pixel=platform==='pixel',side=w*.145,y=h*(pixel?.844:.877);
    DOCK_APPS.android.forEach((name,i)=>icon(c,icons[name],w*(.155+i*.23)-side/2,y,side,platform));
    if(pixel)search(c,w*.17,h*.928,w*.66,h*.047,'#5d6571','#ffffffde');
    else for(let i=0;i<3;i++){c.fillStyle=i===0?color:color==='white'?'#ffffff55':'#00000044';c.beginPath();c.arc(w*(.482+i*.018),h*.829,w*.0035,0,Math.PI*2);c.fill();}
    rect(c,w*.375,h*.99,w*.25,h*.0035,h*.002,color);
  }c.restore();
}
