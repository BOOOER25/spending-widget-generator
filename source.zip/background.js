// Provider boundary: switch config.js to `api` when the Aliyun proxy is ready.
import {config} from './config.js';
let worker,active,sequence=0;
function ensureWorker(){
  if(worker)return;
  worker=new Worker(new URL('./cutout-worker.js',import.meta.url),{type:'module'});
  worker.onmessage=({data})=>{
    if(!active || data.id!==active.id)return;
    if(data.type==='progress')active.progress(data.message);
    else{clearTimeout(active.timer);const task=active;active=null;data.type==='done'?task.resolve(data.blob):task.reject(new Error(data.message));}
  };
  worker.onerror=error=>{console.error('Cutout worker:',error.message,error.filename,error.lineno);if(active){clearTimeout(active.timer);active.reject(new Error('此浏览器未能启动抠图，请用系统浏览器打开，或上传已抠好的透明 PNG'));active=null;}worker?.terminate();worker=null;};
}
export async function removeBackground(blob,progress=()=>{}){
  if(config.provider==='api'){
    if(!config.apiUrl?.startsWith('https://'))throw new Error('图片接口尚未配置');
    const form=new FormData();form.append('file',blob,'product.png');
    const response=await fetch(config.apiUrl,{method:'POST',body:form,signal:AbortSignal.timeout(120000)});
    if(!response.ok)throw new Error('抠图服务暂时不可用，请稍后重试');
    if(response.headers.get('content-type')?.startsWith('image/'))return response.blob();
    const result=await response.json();const url=result.data?.imageUrl;
    if(result.code!==0||!url)throw new Error(result.message||'图片处理失败');
    const image=await fetch(url,{signal:AbortSignal.timeout(30000)});if(!image.ok)throw new Error('无法读取处理结果，请重新抠图');return image.blob();
  }
  if(active)throw new Error('正在处理另一张图片，请稍等');
  ensureWorker();const id=++sequence;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{worker?.terminate();worker=null;active=null;reject(new Error('处理时间较长，请重试，或上传已抠好的透明 PNG'));},240000);
    active={id,resolve,reject,progress,timer};worker.postMessage({id,blob});
  });
}
export function cancelRemoval(){if(active){clearTimeout(active.timer);active.reject(new Error('已取消抠图'));active=null;}worker?.terminate();worker=null;}
