import {widgetFormat} from './templates.js';
// Wallpaper/device simulation is paused. Original implementation: phone-background-legacy.js.
import {drawWidget} from './render.js';
import {resolution,constrain,placeDefault,snapWidget,hitRect,clamp,layoutWidgets} from './phone-core.js';

export function setupPhone({people,appearance,toast,onSelect,onChange}){
  const $=s=>document.querySelector(s),canvas=$('#phone-canvas'),ctx=canvas.getContext('2d');
  // Internal layout space only; export remains unavailable until a screenshot is uploaded.
  const screen={width:680,height:1360,ratio:.423,caption:true,corner:.16,backgroundType:'screenshot'};
  let widgetTypes=people().map(p=>p.template),widgets=layoutWidgets(people().map((p,i)=>{const f=widgetFormat(p);return placeDefault(i,screen,f.ratio,f.width/f.height);}),screen),selected=-1,background=null,backgroundUrl=null,uploadVersion=0,loading=false,exportResult=null,revision=0,drag=null,raf=0;
  const cache=new Map();
  function invalidate(){revision++;if(exportResult)URL.revokeObjectURL(exportResult.url);exportResult=null;onChange?.();}
  function schedule(){invalidate();if(!raf)raf=requestAnimationFrame(()=>{raf=0;paint();});}
  function syncControls(){widgets.forEach((w,i)=>{const visible=$(`[data-visible="${i}"]`);if(visible)visible.checked=w.visible;document.querySelectorAll(`[data-ratio="${i}"]`).forEach(input=>input.value=(w.ratio*100).toFixed(1));});}
  function widgetCanvas(i,width){const p=people()[i];if(!p)return null;const f=widgetFormat(p),pixels=Math.max(f.width,Math.ceil(width)),key=`${i}:${pixels}:${screen.corner}:${p.template}`;if(!cache.has(key)){const c=document.createElement('canvas');c.width=pixels;c.height=Math.round(pixels*f.height/f.width);drawWidget(c,p,{...appearance,corner:screen.corner});cache.set(key,c);}return cache.get(key);}
  function syncTemplates(){const next=people().map(p=>p.template);if(next.some((type,i)=>type!==widgetTypes[i])){widgets=widgets.map((w,i)=>{if(next[i]===widgetTypes[i])return w;const f=widgetFormat(people()[i]);return constrain({...w,ratio:f.ratio,aspect:f.width/f.height},screen);});widgetTypes=next;widgets=layoutWidgets(widgets,screen);syncControls();}}
  function paint(){
    if(!background)return;
    if(canvas.width!==screen.width||canvas.height!==screen.height){canvas.width=screen.width;canvas.height=screen.height;}
    ctx.clearRect(0,0,screen.width,screen.height);
    // One source pixel maps to one canvas pixel: no crop, scaling or simulated desktop chrome.
    ctx.drawImage(background,0,0);
    widgets.forEach((widget,i)=>{
      const hit=$(`#phone-hit-${i}`);hit.hidden=!widget.visible;
      const {x,y,width,height}=hitRect(widget,screen);
      Object.assign(hit.style,{left:`${widget.x*100}%`,top:`${widget.y*100}%`,width:`${widget.ratio*100}%`,height:`${height/screen.height*100}%`,borderRadius:`${Math.min(width,height)*screen.corner/width*100}% / ${screen.corner*100}%`});
      hit.classList.toggle('selected',selected===i);hit.setAttribute('aria-pressed',String(selected===i));
      if(!widget.visible)return;const image=widgetCanvas(i,width);if(!image)return;
      ctx.save();ctx.beginPath();ctx.roundRect(x,y,width,height,height*screen.corner);ctx.clip();ctx.drawImage(image,x,y,width,height);ctx.restore();
      ctx.save();ctx.font=`500 ${screen.width*.028}px system-ui,"PingFang SC","Microsoft YaHei",sans-serif`;ctx.textAlign='center';ctx.textBaseline='top';ctx.fillStyle='white';ctx.shadowColor='#0007';ctx.shadowBlur=screen.width*.004;ctx.fillText('喵喵记账',x+width/2,y+height+screen.width*.012,width);ctx.restore();
    });
    $('#phone-stage').style.aspectRatio=`${screen.width} / ${screen.height}`;
    $('#phone-size-label').textContent=`${screen.width} × ${screen.height}`;syncControls();
  }
  function resetPosition(i){const f=widgetFormat(people()[i]);widgets[i]={...widgets[i],ratio:f.ratio,aspect:f.width/f.height};widgets=layoutWidgets(widgets,screen);cache.clear();syncControls();schedule();}
  async function loadScreenshot(file){
    const version=++uploadVersion;loading=true;invalidate();$('#phone-upload-status').textContent='正在读取截图…';let url;
    try{
      if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('请上传 JPG、PNG 或 WebP 截图');
      if(file.size>30*1024*1024)throw new Error('截图不能超过 30 MB');
      url=URL.createObjectURL(file);const image=new Image();image.src=url;await image.decode();
      const size=resolution(image.naturalWidth,image.naturalHeight);
      if(version!==uploadVersion){URL.revokeObjectURL(url);return;}
      if(backgroundUrl)URL.revokeObjectURL(backgroundUrl);backgroundUrl=url;background=image;
      const dimensionsChanged=screen.width!==size.width||screen.height!==size.height;Object.assign(screen,size);widgets=dimensionsChanged?layoutWidgets(widgets,screen):widgets.map(w=>constrain(w,screen));cache.clear();
      $('#phone-empty').hidden=true;canvas.hidden=false;$('.phone-interactions').hidden=false;$('#phone-stage').classList.remove('empty-preview');
      $('#phone-device-label').textContent='截图原始尺寸';
      $('#phone-upload-status').textContent=`已上传截图 · ${size.width} × ${size.height} · 按原尺寸导出`;
      $('#phone-upload strong').textContent='更换手机截图';syncControls();schedule();
    }catch(error){if(url)URL.revokeObjectURL(url);if(version===uploadVersion){$('#phone-upload-status').textContent=background?`保留上一张截图 · ${screen.width} × ${screen.height}`:'读取失败，请重新选择手机截图';toast(error.message||'截图读取失败，请重试');}}
    finally{if(version===uploadVersion){loading=false;invalidate();}}
  }
  for(const id of ['phone-upload','preview-upload'])$('#'+id).addEventListener('click',()=>$('#phone-background').click());
  $('#phone-background').addEventListener('change',e=>{const file=e.target.files[0];if(file)loadScreenshot(file);e.target.value='';});
  $('#phone-corner').addEventListener('input',e=>{screen.corner=Number(e.target.value)/100;cache.clear();$('#phone-corner-value').textContent=`${e.target.value}%`;schedule();});
  $('#phone-layout-reset').addEventListener('click',()=>{[0,1].forEach(resetPosition);});
  [0,1].forEach(i=>{const hit=$(`#phone-hit-${i}`);
    hit.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();onSelect?.(i);const bounds=canvas.getBoundingClientRect();drag={pointer:e.pointerId,index:i,startX:e.clientX,startY:e.clientY,x:widgets[i].x,y:widgets[i].y,width:bounds.width,height:bounds.height};hit.setPointerCapture(e.pointerId);});
    hit.addEventListener('pointermove',e=>{if(!drag||drag.index!==i||drag.pointer!==e.pointerId)return;widgets[i]=constrain({...widgets[i],x:drag.x+(e.clientX-drag.startX)/drag.width,y:drag.y+(e.clientY-drag.startY)/drag.height},screen);schedule();});
    function endDrag(e){if(!drag||drag.index!==i||drag.pointer!==e.pointerId)return;if($('#phone-snap').checked)widgets[i]=snapWidget(widgets[i],screen);drag=null;schedule();}hit.addEventListener('pointerup',endDrag);hit.addEventListener('pointercancel',endDrag);hit.addEventListener('lostpointercapture',endDrag);
    hit.addEventListener('keydown',e=>{const moves={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};if(!moves[e.key])return;e.preventDefault();onSelect?.(i);const [x,y]=moves[e.key],step=e.shiftKey?10:1;widgets[i]=constrain({...widgets[i],x:widgets[i].x+x*step/screen.width,y:widgets[i].y+y*step/screen.height},screen);schedule();});
  });
  async function exportImage(){
    if(loading)throw new Error('请等待截图读取完成');if(!background)throw new Error('请先上传手机截图');
    if(exportResult)return exportResult;paint();const version=revision;
    const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('截图生成失败，请重试')),'image/png'));
    if(version!==revision)throw new Error('效果已变化，请重新保存');
    exportResult={blob,file:new File([blob],`手机效果-${screen.width}x${screen.height}.png`,{type:'image/png'}),url:URL.createObjectURL(blob)};return exportResult;
  }
  return {refresh(){syncTemplates();cache.clear();schedule();},select(i){selected=i;paint();},syncControls,resetPosition,exportImage,
    getSize:()=>background&&!loading?{width:screen.width,height:screen.height}:null,
    getVisible:()=>widgets.flatMap((w,i)=>w.visible?[i]:[]),
    setVisible(i,visible){widgets[i].visible=visible;schedule();},
    setScale(i,value){const n=Number(value);if(!Number.isFinite(n)||n<1||n>90){toast('展示比例请输入 1–90');syncControls();return;}widgets[i]=constrain({...widgets[i],ratio:clamp(n/100,.01,.9)},screen);cache.clear();syncControls();schedule();}};
}
