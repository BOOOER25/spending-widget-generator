import {coverRect} from './core.js';
import {drawWidget} from './render.js';
import {DEVICES,resolution,constrain,placeDefault,snapWidget,hitRect,clamp} from './phone-core.js';

export function setupPhone({people,appearance,toast,saveImage}){
  const $=s=>document.querySelector(s),canvas=$('#phone-canvas'),ctx=canvas.getContext('2d');
  const screen={...DEVICES[0],caption:false};
  let widgets=[0,1].map(i=>placeDefault(i,screen,screen.ratio)),selected=0,background=null,backgroundUrl=null,uploadVersion=0,exportResult=null,revision=0,drag=null,raf=0;
  const cache=new Map();
  const device=$('#phone-device');
  DEVICES.forEach(d=>{const option=new Option(`${d.name} · ${d.width} × ${d.height}`,d.id);device.add(option);});
  device.add(new Option('自定义分辨率','custom'));
  function invalidate(){revision++;if(exportResult)URL.revokeObjectURL(exportResult.url);exportResult=null;$('#phone-export-link').hidden=true;}
  function schedule(){invalidate();if(!raf)raf=requestAnimationFrame(()=>{raf=0;paint();});}
  function widgetCanvas(index,size){
    const p=people()[index];if(!p)return null;
    const key=`${index}:${Math.max(680,Math.ceil(size))}`;
    if(!cache.has(key)){
      const c=document.createElement('canvas');c.width=c.height=Number(key.split(':')[1]);drawWidget(c,p,appearance);cache.set(key,c);
    }
    return cache.get(key);
  }
  function paint(){
    if(canvas.width!==screen.width||canvas.height!==screen.height){canvas.width=screen.width;canvas.height=screen.height;}
    ctx.clearRect(0,0,screen.width,screen.height);ctx.fillStyle='#8fa1b8';ctx.fillRect(0,0,screen.width,screen.height);
    ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
    if(background){
      if($('#background-fit').value==='contain'){
        const factor=Math.min(screen.width/background.naturalWidth,screen.height/background.naturalHeight);
        const w=background.naturalWidth*factor,h=background.naturalHeight*factor;ctx.drawImage(background,(screen.width-w)/2,(screen.height-h)/2,w,h);
      }else{const r=coverRect(background.naturalWidth,background.naturalHeight,screen.width,screen.height);ctx.drawImage(background,r.x,r.y,r.w,r.h);}
    }
    widgets.forEach((widget,i)=>{
      const hit=$(`#phone-hit-${i}`);hit.hidden=!widget.visible;
      const {x,y,size}=hitRect(widget,screen);
      Object.assign(hit.style,{left:`${widget.x*100}%`,top:`${widget.y*100}%`,width:`${widget.ratio*100}%`,height:`${size/screen.height*100}%`,borderRadius:`${screen.platform==='ios'?21:15}%`});
      hit.classList.toggle('selected',selected===i);hit.setAttribute('aria-pressed',String(selected===i));
      if(!widget.visible)return;
      const image=widgetCanvas(i,size);if(!image)return;
      ctx.save();ctx.beginPath();ctx.roundRect(x,y,size,size,size*(screen.platform==='ios'?.21:.15));ctx.clip();ctx.drawImage(image,x,y,size,size);ctx.restore();
      if(screen.caption){ctx.save();ctx.font=`500 ${screen.width*.029}px "PingFang SC","Microsoft YaHei",sans-serif`;ctx.textAlign='center';ctx.textBaseline='top';ctx.fillStyle='white';ctx.shadowColor='#0009';ctx.shadowBlur=screen.width*.006;ctx.fillText($('#phone-caption').value.trim()||'喵喵记账',x+size/2,y+size+screen.width*.012,size);ctx.restore();}
    });
    $('#phone-stage').style.aspectRatio=`${screen.width} / ${screen.height}`;
    $('#phone-size-label').textContent=`${screen.width} × ${screen.height} px · PNG`;
    $('#phone-platform-note').textContent=screen.platform==='ios'?'按 iPhone 小号组件比例模拟，可自行微调。':'安卓按通用桌面比例模拟，可按实际桌面微调。';
  }
  function syncControls(){
    widgets.forEach((w,i)=>{$(`#phone-visible-${i}`).checked=w.visible;});
    document.querySelectorAll('[data-phone-select]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.phoneSelect)===selected)));
    $('#phone-scale').value=(widgets[selected].ratio*100).toFixed(1);$('#phone-scale-number').value=(widgets[selected].ratio*100).toFixed(1);
    $('#phone-scale-label').textContent=`${selected===0?'我的':'对方的'}小组件大小`;
    $('#phone-width').value=screen.width;$('#phone-height').value=screen.height;
  }
  function applyResolution(width,height){
    Object.assign(screen,resolution(width,height));widgets=widgets.map(w=>constrain(w,screen));cache.clear();syncControls();schedule();
  }
  device.addEventListener('change',()=>{
    const d=DEVICES.find(d=>d.id===device.value);if(!d){$('#phone-advanced').open=true;$('#phone-width').focus();return;}
    Object.assign(screen,d);$('#phone-platform').value=d.platform;
    widgets=widgets.map((w,i)=>({...placeDefault(i,screen,d.ratio),visible:w.visible}));cache.clear();syncControls();schedule();
  });
  $('#apply-resolution').addEventListener('click',()=>{
    try{applyResolution($('#phone-width').value,$('#phone-height').value);device.value='custom';toast('分辨率已更新');}catch(e){toast(e.message);}
  });
  $('#phone-platform').addEventListener('change',e=>{screen.platform=e.target.value;schedule();});
  async function loadBackground(source,isDefault=false){
    const version=++uploadVersion;$('#phone-upload-status').textContent='正在加载背景…';
    let url=source;
    try{
      if(source instanceof File){
        if(!['image/jpeg','image/png','image/webp'].includes(source.type))throw new Error('请上传 JPG、PNG 或 WebP 截图');
        if(source.size>30*1024*1024)throw new Error('背景图片请控制在 30 MB 以内');
        url=URL.createObjectURL(source);
      }
      const image=new Image();image.src=url;await image.decode();
      if(image.naturalWidth*image.naturalHeight>50000000)throw new Error('图片尺寸过大，请使用手机原始截图');
      if(version!==uploadVersion){if(url.startsWith('blob:'))URL.revokeObjectURL(url);return;}
      if(backgroundUrl)URL.revokeObjectURL(backgroundUrl);
      backgroundUrl=url.startsWith('blob:')?url:null;background=image;
      $('#phone-upload-status').textContent=`${isDefault?'默认截图':'已上传截图'} · ${image.naturalWidth} × ${image.naturalHeight}`;
      $('#use-background-size').disabled=false;schedule();
    }catch(e){if(url.startsWith('blob:'))URL.revokeObjectURL(url);if(version===uploadVersion){$('#phone-upload-status').textContent=background?'保留上一张背景':'背景加载失败，请上传截图';toast(e.message||'背景加载失败，请重试');}}
  }
  $('#phone-upload').addEventListener('click',()=>$('#phone-background').click());
  $('#phone-background').addEventListener('change',e=>{const file=e.target.files[0];if(file)loadBackground(file);e.target.value='';});
  $('#phone-default-background').addEventListener('click',()=>loadBackground('./phone-background.png',true));
  $('#use-background-size').addEventListener('click',()=>{
    if(!background)return;
    try{applyResolution(background.naturalWidth,background.naturalHeight);device.value=DEVICES.find(d=>d.width===screen.width&&d.height===screen.height&&d.platform===screen.platform)?.id||'custom';toast('已使用截图原始分辨率，背景完整保留');}catch(e){toast(e.message);}
  });
  $('#background-fit').addEventListener('change',schedule);
  document.querySelectorAll('[data-phone-select]').forEach(button=>button.addEventListener('click',()=>{selected=Number(button.dataset.phoneSelect);syncControls();paint();}));
  [0,1].forEach(i=>{
    $(`#phone-visible-${i}`).addEventListener('change',e=>{widgets[i].visible=e.target.checked;if(widgets[i].visible)selected=i;syncControls();schedule();});
    const hit=$(`#phone-hit-${i}`);
    hit.addEventListener('pointerdown',e=>{
      if(e.button!==0)return;e.preventDefault();selected=i;syncControls();paint();
      const bounds=canvas.getBoundingClientRect();drag={pointer:e.pointerId,index:i,startX:e.clientX,startY:e.clientY,x:widgets[i].x,y:widgets[i].y,width:bounds.width,height:bounds.height};hit.setPointerCapture(e.pointerId);
    });
    hit.addEventListener('pointermove',e=>{
      if(!drag||drag.pointer!==e.pointerId)return;
      widgets[i]=constrain({...widgets[i],x:drag.x+(e.clientX-drag.startX)/drag.width,y:drag.y+(e.clientY-drag.startY)/drag.height},screen);schedule();
    });
    function endDrag(e){if(!drag||drag.pointer!==e.pointerId)return;if($('#phone-snap').checked)widgets[i]=snapWidget(widgets[i],screen);drag=null;schedule();}
    hit.addEventListener('pointerup',endDrag);hit.addEventListener('pointercancel',endDrag);hit.addEventListener('lostpointercapture',endDrag);
    hit.addEventListener('keydown',e=>{
      const moves={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};if(!moves[e.key])return;
      e.preventDefault();selected=i;const [x,y]=moves[e.key],step=e.shiftKey?10:1;
      widgets[i]=constrain({...widgets[i],x:widgets[i].x+x*step/screen.width,y:widgets[i].y+y*step/screen.height},screen);syncControls();schedule();
    });
  });
  function setScale(value){
    const percent=Number(value);if(!Number.isFinite(percent)||percent<1||percent>90)return false;
    const limit=Math.min(.9,screen.height/screen.width-(screen.caption?.05:0));
    widgets[selected]=constrain({...widgets[selected],ratio:clamp(percent/100,.01,limit)},screen);cache.clear();syncControls();schedule();return true;
  }
  $('#phone-scale').addEventListener('input',e=>setScale(e.target.value));
  $('#phone-scale-number').addEventListener('change',e=>{if(!setScale(e.target.value)){toast('展示比例请输入 1–90，表示占屏幕宽度的百分比');syncControls();}});
  $('#phone-layout-reset').addEventListener('click',()=>{const ratio=DEVICES.find(d=>d.id===device.value)?.ratio||.423;widgets=widgets.map((w,i)=>({...placeDefault(i,screen,ratio),visible:w.visible}));cache.clear();syncControls();schedule();});
  $('#phone-show-caption').addEventListener('change',e=>{screen.caption=e.target.checked;$('#phone-caption-label').hidden=!screen.caption;widgets=widgets.map(w=>constrain(w,screen));schedule();});
  $('#phone-caption').addEventListener('input',schedule);
  $('#save-phone').addEventListener('click',async()=>{
    if(!background)return toast('请先等待背景加载完成，或上传截图');
    const button=$('#save-phone');button.disabled=true;
    try{
      // Share already-prepared files on subsequent taps, preserving user activation.
      if(exportResult){await saveImage(exportResult);return;}
      paint();const version=revision;
      const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('截图生成失败，请重试')),'image/png'));
      if(version!==revision)return toast('效果已变化，请重新保存');
      exportResult={blob,file:new File([blob],`手机效果-${screen.width}x${screen.height}.png`,{type:'image/png'}),url:URL.createObjectURL(blob)};
      const link=$('#phone-export-link');link.href=exportResult.url;link.hidden=false;
      await saveImage(exportResult);
    }catch(e){toast(e.message||'保存失败，请重试');}finally{button.disabled=false;}
  });
  document.querySelectorAll('[data-result-tab]').forEach(button=>button.addEventListener('click',()=>{
    const phone=button.dataset.resultTab==='phone';$('#phone-editor').hidden=!phone;$('#single-results').hidden=phone;
    document.querySelectorAll('[data-result-tab]').forEach(b=>b.setAttribute('aria-selected',String(b===button)));if(phone)paint();
  }));
  syncControls();paint();loadBackground('./phone-background.png',true);
  return {refresh(){cache.clear();schedule();}};
}
