// Physical screenshot pixels. Android widget sizing varies by launcher.
export const DEVICES=[
  {id:'iphone16pro',name:'iPhone 16 Pro',width:1206,height:2622,platform:'ios',ratio:170/402},
  {id:'iphone16promax',name:'iPhone 16 Pro Max',width:1320,height:2868,platform:'ios',ratio:186/440},
  {id:'iphone17pro',name:'iPhone 17 Pro',width:1206,height:2622,platform:'ios',ratio:170/402},
  {id:'iphone17promax',name:'iPhone 17 Pro Max',width:1320,height:2868,platform:'ios',ratio:186/440},
  {id:'galaxys25ultra',name:'Samsung Galaxy S25 Ultra',width:1440,height:3120,platform:'samsung',ratio:.42},
  {id:'xiaomi15ultra',name:'小米 15 Ultra',width:1440,height:3200,platform:'xiaomi',ratio:.42},
  {id:'pixel10pro',name:'Google Pixel 10 Pro',width:1280,height:2856,platform:'pixel',ratio:.42},
];
export function resolution(width,height){
  width=Number(width);height=Number(height);
  if(!Number.isInteger(width)||!Number.isInteger(height)||width<320||width>4096||height<320||height>8192||width*height>16000000)
    throw new Error('请输入有效像素尺寸：宽 320–4096，高 320–8192，总像素不超过 1600 万');
  return {width,height};
}
export const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
export function constrain(widget,screen){
  const ratio=Math.min(widget.ratio,1,screen.height/screen.width-(screen.caption?.05:0));
  const side=ratio*screen.width;
  return {...widget,ratio,x:clamp(widget.x,0,1-ratio),y:clamp(widget.y,0,Math.max(0,1-(side+(screen.caption?screen.width*.05:0))/screen.height))};
}
export function placeDefault(index,screen,ratio){
  const margin=.06,top=.104,step=(ratio+.045)*screen.width/screen.height;
  return constrain({visible:true,ratio,x:index===0?margin:1-margin-ratio,y:top+(screen.backgroundType==='screenshot'?step:0)},screen);
}
export function snapWidget(widget,screen){
  const margin=.06,step=(widget.ratio+.045)*screen.width/screen.height;
  const xs=[margin,1-margin-widget.ratio];
  const nearest=xs.reduce((a,b)=>Math.abs(widget.x-a)<Math.abs(widget.x-b)?a:b);
  const y=.104+Math.round((widget.y-.104)/step)*step;
  return constrain({...widget,x:nearest,y},screen);
}
export function hitRect(widget,screen){return {x:widget.x*screen.width,y:widget.y*screen.height,size:widget.ratio*screen.width};}
