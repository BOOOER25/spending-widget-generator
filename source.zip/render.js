import {drawTrueWidget,contentLayer} from './templates.js';
import {coverRect, clippedText} from './core.js';
const SYSTEM_FONT='system-ui,"PingFang SC","Microsoft YaHei",sans-serif';
export let FONT=SYSTEM_FONT;
export function setWidgetFont(choice){FONT=choice==='puhui'?'"Widget Inter","Widget PuHui",'+SYSTEM_FONT:SYSTEM_FONT;}
let fontDownload=null;
function rounded(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=.7;c.stroke();}}
function label(c,text,x,y,size,color='#443936',weight=500,width=Infinity,align='left'){
  c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';
  c.fillText(clippedText(c,String(text),width),x,y);
}
function imageSource(image){return image?.bitmap || image;}
export const EXPORT_SIZE=680;
export async function loadWidgetFonts(){
  // Optional only: opening the editor never downloads web fonts.
  if(!fontDownload)fontDownload=Promise.all([
    document.fonts.load('400 10px "Widget Inter"'),
    document.fonts.load('700 10px "Widget Inter"'),
    document.fonts.load('400 10px "Widget PuHui"')
  ]).then(()=>{
    if(!document.fonts.check('400 10px "Widget Inter"')||!document.fonts.check('400 10px "Widget PuHui"'))throw new Error('字体加载失败');
  }).catch(error=>{fontDownload=null;throw error;});
  let timer;
  try{await Promise.race([fontDownload,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('字体下载超时')),30000);})]);}
  finally{clearTimeout(timer);}
}
export function drawWidget(canvas,p,{outline=1.5,shadow=.8,corner=0}={}){
  if(p.template&&p.template!=='fake')return drawTrueWidget(canvas,p,{outline,shadow,corner},FONT);
  const scale=canvas.width/170,c=canvas.getContext('2d');c.setTransform(scale,0,0,scale,0,0);c.clearRect(0,0,170,170);
  c.fillStyle='#FED55E';c.fillRect(0,0,170,170);
  // Keep the inner contour concentric with the phone widget's outer corner.
  rounded(c,6,6,158,158,Math.max(0,170*corner-6),'#FFF');
  if(p.avatar){c.save();c.beginPath();c.arc(22,22,11,0,Math.PI*2);c.clip();const img=imageSource(p.avatar),r=coverRect(img.width||img.naturalWidth,img.height||img.naturalHeight,22,22);c.drawImage(img,11+r.x,11+r.y,r.w,r.h);c.restore();}
  const total=Number.isFinite(Number(p.total))?Number(p.total||0).toFixed(2).replace(/\.00$/,''):'—';
  // Different type sizes share one baseline; the complete group stays right aligned.
  const totalLayer=document.createElement('canvas');totalLayer.width=totalLayer.height=canvas.width;
  const tc=totalLayer.getContext('2d');tc.scale(scale,scale);tc.textBaseline='alphabetic';
  const segments=[{text:'今日:',size:8,color:'rgba(245,108,130,0.50)'},{text:'￥',size:8,color:'#F56C82'},{text:total,size:13,color:'#F56C82'}];
  for(const segment of segments){tc.font=`700 ${segment.size}px ${FONT}`;segment.width=tc.measureText(segment.text).width;}
  let totalX=157-segments.reduce((width,segment)=>width+segment.width,0);
  for(const segment of segments){tc.font=`700 ${segment.size}px ${FONT}`;tc.fillStyle=segment.color;tc.fillText(segment.text,totalX,24);totalX+=segment.width;}
  c.save();c.shadowColor='rgba(0,0,0,0.08)';c.shadowOffsetX=scale;c.shadowOffsetY=scale;c.shadowBlur=5*scale;c.drawImage(totalLayer,0,0,170,170);c.restore();
  function paintContent(record){
  const item=record.mode==='cutout'?record.cutout:record.image;
  if(item){
    const img=imageSource(item),iw=img.width||img.naturalWidth,ih=img.height||img.naturalHeight;
    if(record.mode==='photo'){
      c.save();c.beginPath();c.roundRect(35,34,100,92,3);c.clip();
      const r=coverRect(iw,ih,100,92,record.zoom,record.x,record.y);c.drawImage(img,35+r.x,34+r.y,r.w,r.h);c.restore();
    }else{
      const f=Math.min(108/iw,94/ih)*(record.size||1),w=iw*f,h=ih*f,x=(170-w)/2,y=32+(94-h)/2;
      const layer=document.createElement('canvas');layer.width=layer.height=canvas.width;
      const l=layer.getContext('2d');l.scale(scale,scale);l.drawImage(img,x,y,w,h);l.globalCompositeOperation='source-in';l.fillStyle='white';l.fillRect(0,0,170,170);
      const sticker=document.createElement('canvas');sticker.width=sticker.height=canvas.width;
      const t=sticker.getContext('2d');t.scale(scale,scale);t.drawImage(layer,0,0,170,170);
      if(outline>0)for(let a=0;a<360;a+=10)t.drawImage(layer,Math.cos(a*Math.PI/180)*outline,Math.sin(a*Math.PI/180)*outline,170,170);
      c.save();c.shadowColor=`rgba(50,42,38,${.24*shadow})`;c.shadowBlur=4.5*scale;c.shadowOffsetY=3*scale;
      c.drawImage(sticker,0,0,170,170);c.shadowColor='transparent';c.shadowBlur=0;c.shadowOffsetY=0;c.drawImage(img,x,y,w,h);c.restore();
    }
  }else{rounded(c,35,34,100,92,3,'#f7f5f2');label(c,'请上传商品图片',85,80,9,'#a58b90',400,95,'center');}
  // Composite the stroked glyphs once, so their soft shadow is not doubled.
  function caption(text,y,color,weight){
    const layer=document.createElement('canvas');layer.width=layer.height=canvas.width;
    const t=layer.getContext('2d');t.scale(scale,scale);t.font=`${weight} 10px ${FONT}`;t.textAlign='center';t.textBaseline='middle';t.lineJoin='round';t.lineWidth=1;t.strokeStyle='#FFF';t.fillStyle=color;
    const value=clippedText(t,text,144);t.strokeText(value,85,y);t.fillText(value,85,y);
    c.save();c.shadowColor='rgba(0,0,0,0.10)';c.shadowOffsetX=scale;c.shadowOffsetY=scale;c.shadowBlur=5*scale;c.drawImage(layer,0,0,170,170);c.restore();
  }
  caption(record.name||'商品名称',135.5,'#000',400);
  const amount=Number.isFinite(Number(record.amount))?Number(record.amount||0).toFixed(2):'—';
  caption('￥'+amount,151.5,'#F56C82',700);
  }
  if(p.previousContent)contentLayer(c,p.exitMotion,[12,30,146,130],()=>paintContent({...p,...p.previousContent}));
  contentLayer(c,p.contentMotion,[12,30,146,130],()=>paintContent(p));
}

export function exportPng(canvas){
  const output=document.createElement('canvas');output.width=canvas.width;output.height=canvas.height;
  const c=output.getContext('2d');c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';c.drawImage(canvas,0,0);
  return new Promise((resolve,reject)=>output.toBlob(b=>b?resolve(b):reject(new Error('图片导出失败，请重试')),'image/png'));
}

export async function decodedImage(blob){
  if(!blob.type.startsWith('image/'))throw new Error('请选择图片文件');
  const url=URL.createObjectURL(blob),img=new Image();
  try{await new Promise((res,rej)=>{img.onload=res;img.onerror=()=>rej(new Error('暂不支持这张图片，请使用 JPG、PNG 或 WebP'));img.src=url;});
    const w=img.naturalWidth,h=img.naturalHeight;if(!w||!h)throw new Error('图片尺寸无效');
    const f=Math.min(1,1600/Math.max(w,h));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(w*f));canvas.height=Math.max(1,Math.round(h*f));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
    const normalized=await new Promise(r=>canvas.toBlob(r,'image/png'));
    return {bitmap:canvas,blob:normalized,url:URL.createObjectURL(normalized)};
  }finally{URL.revokeObjectURL(url);}
}

export async function trimTransparent(blob){
  const im=await decodedImage(blob),c=im.bitmap,ctx=c.getContext('2d',{willReadFrequently:true}),{data}=ctx.getImageData(0,0,c.width,c.height);
  let x0=c.width,y0=c.height,x1=-1,y1=-1;
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(data[(y*c.width+x)*4+3]>20){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
  if(x1<0){URL.revokeObjectURL(im.url);throw new Error('没有识别到清晰的商品，请换一张图片');}
  const out=document.createElement('canvas');out.width=x1-x0+1;out.height=y1-y0+1;out.getContext('2d').drawImage(c,x0,y0,out.width,out.height,0,0,out.width,out.height);
  const result=await new Promise(r=>out.toBlob(r,'image/png'));URL.revokeObjectURL(im.url);return decodedImage(result);
}
