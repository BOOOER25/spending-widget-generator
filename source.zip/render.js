import {coverRect, clippedText} from './core.js';
const FONT='"PingFang SC","Microsoft YaHei",system-ui,sans-serif';
function rounded(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=.7;c.stroke();}}
function label(c,text,x,y,size,color='#443936',weight=500,width=Infinity,align='left'){
  c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';
  c.fillText(clippedText(c,String(text),width),x,y);
}
function imageSource(image){return image?.bitmap || image;}
export const EXPORT_SIZE=680;
export function drawWidget(canvas,p,{outline=2.5,shadow=1}={}){
  const scale=canvas.width/170,c=canvas.getContext('2d');c.setTransform(scale,0,0,scale,0,0);c.clearRect(0,0,170,170);
  rounded(c,.5,.5,169,169,17,'#fff7f7','#efbac3');
  if(p.avatar){c.save();c.beginPath();c.arc(18,18,9,0,Math.PI*2);c.clip();c.drawImage(imageSource(p.avatar),9,9,18,18);c.restore();}
  label(c,p.name||'你的 ID',32,18,10.5,'#443936',650,49);
  rounded(c,87,10,74,17,8.5,'#fff0cc');
  const total=Number(p.total||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2,useGrouping:false});
  label(c,`今日 ¥${total}`,124,18.5,8.6,'#755521',500,67,'center');
  const item=p.mode==='cutout'?p.cutout:p.image;
  if(item){
    const img=imageSource(item);
    if(p.mode==='photo'){
      c.save();c.beginPath();c.roundRect(9,34,152,105,10);c.clip();
      const r=coverRect(img.width||img.naturalWidth,img.height||img.naturalHeight,152,105,p.zoom,p.x,p.y);
      c.drawImage(img,9+r.x,34+r.y,r.w,r.h);c.restore();
    }else{
      const iw=img.width||img.naturalWidth,ih=img.height||img.naturalHeight;
      const f=Math.min(137/iw,109/ih)*p.size;
      const w=iw*f,h=ih*f,x=(170-w)/2,y=34+(109-h)/2;
      // A silhouette canvas creates one outside contour; internal details stay intact.
      const layer=document.createElement('canvas');layer.width=680;layer.height=680;
      const l=layer.getContext('2d');l.scale(4,4);l.drawImage(img,x,y,w,h);l.globalCompositeOperation='source-in';l.fillStyle='white';l.fillRect(0,0,170,170);
      c.save();c.beginPath();c.roundRect(6,31,158,114,12);c.clip();
      // Build the complete white contour before casting one soft shadow.
      const sticker=document.createElement('canvas');sticker.width=sticker.height=680;
      const s=sticker.getContext('2d');s.scale(4,4);s.drawImage(layer,0,0,170,170);
      if(outline>0)for(let a=0;a<360;a+=10)s.drawImage(layer,Math.cos(a*Math.PI/180)*outline,Math.sin(a*Math.PI/180)*outline,170,170);
      // Canvas shadow distances use device pixels, so scale them with the output.
      c.shadowColor=`rgba(50,42,38,${.24*shadow})`;c.shadowBlur=4.5*scale;c.shadowOffsetY=3*scale;
      c.drawImage(sticker,0,0,170,170);c.shadowColor='transparent';c.shadowBlur=0;c.shadowOffsetY=0;
      c.drawImage(img,x,y,w,h);c.restore();
    }
  }else{
    rounded(c,9,34,152,105,10,'#f9e9ec');
    label(c,p.mode==='cutout'?'完成抠图后在这里展示':'上传一张喜欢的商品照片',85,87,9,'#a58b90',400,143,'center');
  }
  const amount=Number(p.amount||0).toFixed(2);let fs=20;c.font=`700 ${fs}px ${FONT}`;
  while(c.measureText('¥'+amount).width>89 && fs>13){fs--;c.font=`700 ${fs}px ${FONT}`;}
  label(c,'¥'+amount,9,155,fs,'#ca727f',700,89);
  label(c,`${p.category||'分类'} · ${p.time||'--:--'}`,161,156,8.1,'#7a6866',400,62,'right');
}

export function exportPng(canvas){
  const output=document.createElement('canvas');output.width=output.height=EXPORT_SIZE;
  const c=output.getContext('2d');c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';c.drawImage(canvas,0,0,EXPORT_SIZE,EXPORT_SIZE);
  return new Promise((resolve,reject)=>output.toBlob(b=>b?resolve(b):reject(new Error('图片导出失败，请重试')),'image/png'));
}

export async function decodedImage(blob){
  if(!blob.type.startsWith('image/'))throw new Error('请选择图片文件');
  const url=URL.createObjectURL(blob),img=new Image();
  try{await new Promise((res,rej)=>{img.onload=res;img.onerror=()=>rej(new Error('暂不支持这张图片，请使用 JPG、PNG 或 WebP'));img.src=url;});
    const w=img.naturalWidth,h=img.naturalHeight;if(!w||!h)throw new Error('图片尺寸无效');
    const f=Math.min(1,1600/Math.max(w,h));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(w*f));canvas.height=Math.max(1,Math.round(h*f));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
    const normalized=await new Promise(r=>canvas.toBlob(r,'image/png'));
    return {bitmap:canvas,blob:normalized,url:URL.createObjectURL(normalized)};
  }finally{URL.revokeObjectURL(url);}
}

export async function trimTransparent(blob){
  const im=await decodedImage(blob),c=im.bitmap,ctx=c.getContext('2d',{willReadFrequently:true}),{data}=ctx.getImageData(0,0,c.width,c.height);
  let x0=c.width,y0=c.height,x1=-1,y1=-1;
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(data[(y*c.width+x)*4+3]>20){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
  if(x1<0){URL.revokeObjectURL(im.url);throw new Error('没有识别到清晰的商品，请换一张图片');}
  const out=document.createElement('canvas');out.width=x1-x0+1;out.height=y1-y0+1;out.getContext('2d').drawImage(c,x0,y0,out.width,out.height,0,0,out.width,out.height);
  const result=await new Promise(r=>out.toBlob(r,'image/png'));URL.revokeObjectURL(im.url);return decodedImage(result);
}
