import {coverRect,clippedText} from './core.js';
export const TEMPLATES={
  fake:{name:'假小组件（原样式）',width:680,height:680,logicalWidth:170,logicalHeight:170,ratio:.423},
  small:{name:'真小组件',width:444,height:444,logicalWidth:148,logicalHeight:148,ratio:148/375},
  day:{name:'今日消费对比',width:966,height:444,logicalWidth:322,logicalHeight:148,ratio:322/375},
  month:{name:'本月消费对比',width:966,height:444,logicalWidth:322,logicalHeight:148,ratio:322/375}
};
export function widgetFormat(p){return TEMPLATES[p.template]||TEMPLATES.fake;}
export function defaultComparison(){return {updated:'11:20',left:{name:'我',total:'62.39',monthTotal:'537.61',count:'10',latestAmount:'17.61',category:'餐饮',time:'17:00',avatar:null,rows:[{name:'餐饮',amount:'280',icon:'food'},{name:'日用',amount:'170',icon:'daily'},{name:'交通',amount:'87.61',icon:'transport'}]},right:{name:'小鱼',total:'33.00',monthTotal:'650.00',count:'12',latestAmount:'17.61',category:'日用',time:'07:23',avatar:null,rows:[{name:'餐饮',amount:'280',icon:'food'},{name:'日用',amount:'170',icon:'daily'},{name:'交通',amount:'200',icon:'transport'}]}};}
const assets=new Map(),downloads=new Map();
function load(name){if(assets.has(name))return Promise.resolve(assets.get(name));if(!downloads.has(name))downloads.set(name,(async()=>{const image=new Image();image.src='./true-'+name+'.png';await image.decode();assets.set(name,image);return image;})().catch(error=>{downloads.delete(name);throw error;}));return downloads.get(name);}
export async function loadTemplateAssets(template){
  const names=template==='small'?['small-left-frame','small-right-frame']:template==='day'?['day-frame','pk','avatar-me','avatar-partner','icon-food','icon-daily','icon-transport']:template==='month'?['month-frame','avatar-me','avatar-partner','icon-food','icon-daily','icon-transport']:[];
  await Promise.all(names.map(load));
}
export const isComparison=p=>p.template==='day'||p.template==='month';
const pink='#f47896',orange='#ff8948';
const numeric=value=>Number.isFinite(Number(value))?Number(value):0;
const price=value=>numeric(value).toFixed(2);
const shortPrice=value=>price(value).replace(/\.00$/,'');
function source(image){return image?.bitmap||image;}
function round(c,x,y,w,h,r,fill){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();}
function text(c,value,x,y,size,color,font,align='left',weight=400,width=Infinity){c.save();c.font=`${weight} ${size}px ${font}`;c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';c.fillText(clippedText(c,String(value),width),x,y);c.restore();}
function avatar(c,image,x,y,r){if(!image)return;const im=source(image);c.save();c.shadowColor='#77345225';c.shadowBlur=1;round(c,x-r-1,y-r-1,r*2+2,r*2+2,r+1,'white');c.shadowBlur=0;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();const b=coverRect(im.width||im.naturalWidth,im.height||im.naturalHeight,r*2,r*2);c.drawImage(im,x-r+b.x,y-r+b.y,b.w,b.h);c.restore();}
function icon(c,key,x,y,size){const im=assets.get('icon-'+key)||assets.get('icon-food');if(im)c.drawImage(im,x-size/2,y-size/2,size,size);}
function frame(c,p,key,w,h){if(p.theme!=='transparent'){c.fillStyle=p.baseColor||(p.theme==='mint'?'#b7e8d4':'#ffdc67');c.fillRect(0,0,w,h);}const im=assets.get(key);if(im)c.drawImage(im,0,0,w,h);return im;}
export function contentLayer(c,pose,bounds,paint){
  c.save();
  if(pose){
    const [x,y,w,h]=bounds,cx=x+w/2,cy=y+h/2;
    c.beginPath();c.rect(x,y,w,h);c.clip();
    c.globalAlpha*=pose.alpha;c.translate(cx,cy+pose.y);c.scale(pose.scale,pose.scale);c.translate(-cx,-cy);
  }
  paint();c.restore();
}
export function drawTrueWidget(canvas,p,appearance,font){
  const f=widgetFormat(p),c=canvas.getContext('2d');c.setTransform(canvas.width/f.logicalWidth,0,0,canvas.height/f.logicalHeight,0,0);c.clearRect(0,0,f.logicalWidth,f.logicalHeight);
  if(p.template==='small'){
    const key=p.skin==='right'?'small-right-frame':'small-left-frame',im=frame(c,p,key,148,148);
    if(!im){text(c,p.templateError?'样式加载失败':'正在加载样式…',74,74,10,'#7c7c7c','system-ui','center');return;}
    const paintSmall=record=>{
    const item=record.mode==='cutout'?record.cutout:record.image;
    c.save();c.translate(76,62);c.rotate(p.skin==='right'?-.035:.055);
    c.shadowColor='#0003';c.shadowBlur=3;c.shadowOffsetY=2;round(c,-57,-35,114,70,11,'#fff');c.shadowColor='transparent';
    if(item){const product=source(item),iw=product.width||product.naturalWidth,ih=product.height||product.naturalHeight;c.save();c.beginPath();c.roundRect(-54,-32,108,64,9);c.clip();
      if(record.mode==='photo'){const r=coverRect(iw,ih,108,64,record.zoom,record.x,record.y);c.drawImage(product,-54+r.x,-32+r.y,r.w,r.h);}
      else {const scale=Math.min(100/iw,58/ih)*(record.size||1),w=iw*scale,h=ih*scale;c.shadowColor=`rgba(50,42,38,${.24*appearance.shadow})`;c.shadowBlur=3;c.shadowOffsetY=2;
        if(appearance.outline>0){const layer=document.createElement('canvas');layer.width=iw;layer.height=ih;const lc=layer.getContext('2d');lc.drawImage(product,0,0);lc.globalCompositeOperation='source-in';lc.fillStyle='white';lc.fillRect(0,0,iw,ih);for(let a=0;a<360;a+=20)c.drawImage(layer,-w/2+Math.cos(a*Math.PI/180)*appearance.outline,-h/2+Math.sin(a*Math.PI/180)*appearance.outline,w,h);}
        c.drawImage(product,-w/2,-h/2,w,h);
      }c.restore();}
    c.restore();
    text(c,'−'+price(record.amount),26,115,11.8,pink,font,'left',400,49);
    text(c,`${record.category||'餐饮'}${p.showTime===false?'':' '+(record.time||'07:23')}`,119,115,8.2,'#969696',font,'right',400,49);
    };
    if(p.previousContent)contentLayer(c,p.exitMotion,[14,26,124,100],()=>paintSmall({...p,...p.previousContent}));
    contentLayer(c,p.contentMotion,[14,26,124,100],()=>paintSmall(p));
    c.drawImage(im,0,0,444,78,0,0,148,26);avatar(c,p.avatar,p.skin==='right'?122:26,25,10);
    return;
  }
  const isDay=p.template==='day';const im=frame(c,p,isDay?'day-frame':'month-frame',322,148);
  if(!im){text(c,p.templateError?'样式加载失败':'正在加载样式…',161,74,10,'#7c7c7c','system-ui','center');return;}
  const cmp=p.comparison||defaultComparison(),a=cmp.left,b=cmp.right;
  const avA=a.avatar||assets.get('avatar-me'),avB=b.avatar||assets.get('avatar-partner');
  if(isDay){
    avatar(c,avA,36,42,12.5);avatar(c,avB,277,42,12.5);
    text(c,a.name,59,42,10,'#151515',font,'left',500,52);text(c,b.name,252,42,10,'#151515',font,'right',500,52);
    text(c,'今日消费对比',161,42,9.5,'#dd7d9d',font,'center',500,93);
    const total=numeric(a.total)+numeric(b.total),left=Number.isFinite(a.ratio)?Math.min(1,Math.max(0,a.ratio)):(total?numeric(a.total)/total:0),right=Number.isFinite(b.ratio)?Math.min(1,Math.max(0,b.ratio)):(total?numeric(b.total)/total:0);
    round(c,22,61,139,9.5,5,'#ffedf2');round(c,161,61,129,9.5,5,'#fff4d3');
    if(left>0)round(c,22,61,139*left,9.5,Math.min(4.7,139*left/2),'#ff86a3');
    if(right>0)round(c,290-139*right,61,139*right,9.5,Math.min(4.7,139*right/2),'#ffda62');
    const pk=assets.get('pk');if(pk)c.drawImage(pk,142,54,33,24);
    text(c,(left*100).toFixed(2)+'%',21,86,15,pink,font);text(c,(right*100).toFixed(2)+'%',290,86,15,orange,font,'right');
    text(c,'消费 ￥'+price(a.total),23,107,10.5,'#777',font,'left',400,112);text(c,'消费 ￥'+price(b.total),290,107,10.5,'#777',font,'right',400,112);
    if(p.showTime!==false)text(c,'更新于'+cmp.updated,161,96,8,'#f8a2bd',font,'center',400,72);
    for(const [side,x,tx] of [[a,30,40],[b,196,206]]){
      const bounds=[x-9,115,side===a?134:102,22];
      const paint=record=>{icon(c,record.category==='日用'?'daily':record.category==='交通'?'transport':'food',x,126,14);text(c,`−￥${price(record.latestAmount)}  ${record.category}${p.showTime===false?'':' · '+record.time}`,tx,126,7.7,'#929292',font,'left',400,side===a?112:84);};
      if(side.previousLatest)contentLayer(c,side.exitMotion,bounds,()=>paint(side.previousLatest));
      contentLayer(c,side.contentMotion,bounds,()=>paint(side));
    }
  }else{
    round(c,23,24,133,102,12,'#fff5f8');round(c,166,24,133,102,12,'#fffae6');
    avatar(c,avA,154,37,10);avatar(c,avB,168,37,10);
    text(c,'本月消费',33,39,10,'#151515',font);text(c,'本月消费',289,39,10,'#151515',font,'right');
    for(const [side,x,color,bg] of [[a,77,pink,'#ffe0e9'],[b,225,orange,'#fff0c9']]){round(c,x,33,22,11,6,bg);text(c,`${side.count}笔`,x+11,38.5,6.8,color,font,'center',400,20);}
    text(c,'￥'+price(a.monthTotal),33,57,14,pink,font,'left',400,116);text(c,'￥'+price(b.monthTotal),289,57,14,orange,font,'right',400,116);
    for(const [side,left] of [[a,true],[b,false]]){
      const max=Math.max(1,...side.rows.map(r=>numeric(r.amount)))*1.2;
      side.rows.forEach((row,i)=>{const y=76+i*19,ix=left?41:281;icon(c,row.icon,ix,y-1,14);text(c,row.name,left?51:271,y-4,7.1,'#444',font,left?'left':'right',500,46);text(c,'￥'+shortPrice(row.amount),left?146:176,y-4,7.1,'#444',font,left?'right':'left',400,46);round(c,left?51:176,y+2,95,3,1.5,'white');const width=Math.max(0,Math.min(95,95*(Number.isFinite(row.barRatio)?row.barRatio:numeric(row.amount)/max)));if(width>0)round(c,left?51:271-width,y+2,width,3,Math.min(1.5,width/2),left?'#ff86a3':'#ffd85d');});
    }
    if(p.showTime!==false)text(c,'更新于'+cmp.updated,161,136,8,'#dc7595',font,'center',400,105);
  }
}
