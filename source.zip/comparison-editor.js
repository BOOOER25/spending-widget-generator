export function comparisonEditor(){
 const field=(label,path,{money=false,max=12,type='text'}={})=>`<label>${label}<input data-compare="${path}" ${money?'data-money inputmode="decimal"':''} type="${type}" maxlength="${max}"></label>`;
 return `<div class="comparison-editor" hidden>${['left','right'].map((side,i)=>`<section class="compare-person"><h3>${i?'右侧 · 对方':'左侧 · 我'}</h3><div class="compare-avatar"><button type="button" class="avatar-button" data-action="compare-${side}" aria-label="更换对比${i?'右':'左'}侧头像"><img data-compare-avatar="${side}" alt="${i?'对方':'我的'}头像"><span>更换</span></button><span class="control-note">点击更换头像</span></div><input type="file" data-file="compare-${side}" accept="image/jpeg,image/png,image/webp" hidden>
 <div data-compare-view="day">${field('显示名称',side+'.name',{max:8})}${field('今日消费总额',side+'.total',{money:true})}<h4>最近一笔消费</h4><div class="field-grid">${field('消费金额',side+'.latestAmount',{money:true})}${field('分类',side+'.category',{max:6})}</div>${field('消费时间',side+'.time',{type:'time'})}</div>
 <div data-compare-view="month"> <div class="field-grid">${field('本月消费总额',side+'.monthTotal',{money:true})}${field('本月消费笔数',side+'.count',{max:4})}</div><h4>分类消费（最多展示三项）</h4>${[0,1,2].map(row=>`<div class="category-row"><span class="row-index">${row+1}</span><div class="field-grid">${field('分类名称',`${side}.rows.${row}.name`,{max:6})}${field('分类金额',`${side}.rows.${row}.amount`,{money:true})}</div><label>分类图标<select data-compare="${side}.rows.${row}.icon"><option value="food">餐饮</option><option value="daily">日用</option><option value="transport">交通</option></select></label></div>`).join('')}</div></section>`).join('')}
 ${field('数据更新时间','updated',{type:'time'})}<p class="control-note comparison-help"></p></div>`;
}
export function bindComparison(card,p,onChange){
 card.querySelectorAll('[data-compare]').forEach(input=>{const parts=input.dataset.compare.split('.');const get=()=>parts.reduce((v,k)=>v[k],p.comparison);const set=value=>{let target=p.comparison;for(const key of parts.slice(0,-1))target=target[key];target[parts.at(-1)]=value;};input.value=get();input.addEventListener('input',()=>{set(input.value);onChange();});if(input.hasAttribute('data-money'))input.addEventListener('blur',()=>{const n=Number(input.value);if(/^\d{1,6}(\.\d{1,2})?$/.test(input.value)&&Number.isFinite(n)){input.value=n.toFixed(2);set(input.value);onChange();}});});
}
export function syncComparison(card,p){
 const active=p.template==='day'||p.template==='month';card.querySelector('.comparison-editor').hidden=!active;
 if(!active)return;
 card.querySelectorAll('[data-compare-view]').forEach(el=>el.hidden=el.dataset.compareView!==p.template);
 for(const side of ['left','right'])card.querySelector(`[data-compare-avatar="${side}"]`).src=p.comparison[side].avatar?.url||`./true-avatar-${side==='left'?'me':'partner'}.png`;
 card.querySelector('.comparison-help').textContent=p.template==='day'?'消费占比根据双方今日消费总额自动计算；双方均为 0 时显示 0%。':'左右两侧独立配置，三个分类按填写顺序展示。';
}
