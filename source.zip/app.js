import {money,validate} from './core.js';
import {drawWidget,exportPng,decodedImage,trimTransparent} from './render.js';
import {removeBackground,cancelRemoval} from './background.js';

const $=s=>document.querySelector(s);
const defaults=[{name:'小鱼',category:'餐饮',amount:'30.00',total:'60.00',time:'11:24',imagePath:'./pizza.jpg',avatarPath:'./avatar-me.png'},
{name:'阿桃',category:'饮品',amount:'18.00',total:'42.00',time:'14:08',imagePath:'./drink.jpg',avatarPath:'./avatar-partner.png'}];
let people=[],activePerson=0,cropIndex=0,busyPerson=null,revision=0,resultFiles=[],toastTimer,resetVersion=0;
const appearance={outline:2.5,shadow:1};
const canvases=[$('#preview-0'),$('#preview-1')];
function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,6500);}
function release(item){if(item?.url)URL.revokeObjectURL(item.url);}
function clearResults(){for(const result of resultFiles)URL.revokeObjectURL(result.url);resultFiles=[];$('#result-grid').replaceChildren();}
function changed(){revision++;clearResults();render();storeText();}
function storeText(){try{localStorage.setItem('spending-widget-v1',JSON.stringify(people.map(p=>Object.fromEntries(['name','category','amount','total','time'].map(k=>[k,p[k]])))));}catch{}}
function readText(){try{const data=JSON.parse(localStorage.getItem('spending-widget-v1'));return Array.isArray(data)&&data.length===2?data:null;}catch{return null;}}

function cardTemplate(i){const mine=i===0;return `<article class="form-card" data-card="${i}" aria-label="${mine?'我的':'对方的'}信息">
<div class="card-heading"><h3>${mine?'我的信息':'对方的信息'}</h3><span class="required">全部必填</span></div>
<div class="identity"><button class="avatar-button" type="button" data-action="avatar" aria-label="${mine?'更换我的头像':'更换对方头像'}"><img alt="${mine?'我的头像':'对方头像'}"><span>换头像</span></button><label>ID<input data-field="name" maxlength="12" placeholder="${mine?'填写我的 ID':'填写对方 ID'}" autocomplete="off"></label></div>
<div class="subheading">订单信息</div><div class="field-grid">
<label>分类<input data-field="category" maxlength="12" placeholder="手动填写，例如餐饮"></label>
<label>消费金额<input data-field="amount" inputmode="decimal" placeholder="0.00" maxlength="9"></label>
<label>今日消费总金额<input data-field="total" inputmode="decimal" placeholder="0.00" maxlength="9"></label>
<label>消费时间<input data-field="time" type="time" required></label></div>
<span class="upload-label">商品图片</span><button class="image-upload" data-action="image" type="button" aria-label="${mine?'上传我的商品图片':'上传对方商品图片'}"><img alt="商品原图"><span class="upload-overlay">↥ 点击更换图片</span></button>
<div class="image-buttons"><button class="text-button" data-action="image" type="button">上传商品图</button><button class="text-button" data-action="crop" type="button">调整图片位置 ↗</button></div>
<span class="upload-label">这张图片怎么展示？</span><div class="segmented" role="group" aria-label="图片展示方式"><button type="button" data-mode="photo" aria-pressed="true">保留原图</button><button type="button" data-mode="cutout" aria-pressed="false">自动抠图</button></div>
<p class="mode-help"></p><div class="cutout-settings" hidden><div class="cutout-actions"><button type="button" class="text-button" data-action="remove">免费抠图</button><button type="button" class="text-button" data-action="cutout">上传透明 PNG</button></div><label class="size-control">商品大小<input data-field="size" type="range" min=".6" max="1.05" step=".05" value="1"></label></div>
<div class="processing" role="status" aria-live="polite" hidden><span></span><button type="button" class="text-button cancel-button" data-action="cancel">取消处理</button></div>
<input type="file" data-file="image" accept="image/jpeg,image/png,image/webp"><input type="file" data-file="avatar" accept="image/jpeg,image/png,image/webp"><input type="file" data-file="cutout" accept="image/png,image/webp">
</article>`;}

function render(){
  people.forEach((p,i)=>{
    drawWidget(canvases[i],p,appearance);
    $(`#preview-mode-${i}`).textContent=p.mode==='photo'?'保留原图':'透明贴纸';
    const card=$(`[data-card="${i}"]`);if(!card)return;
    card.querySelector('.avatar-button img').src=p.avatar?.url||'';
    card.querySelector('.image-upload img').src=p.image?.url||'';
    card.querySelector('.cutout-settings').hidden=p.mode!=='cutout';
    card.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===p.mode)));
    card.querySelector('.mode-help').textContent=p.mode==='photo'?'保留照片的背景；点击「调整图片位置」可以裁切。':p.cutout?'✓ 抠图完成，已添加白边与柔和阴影。':'自动去掉图片背景，再添加白边和阴影；也可以上传透明 PNG。';
    card.querySelector('[data-action=remove]').textContent=p.cutout?'重新抠图':'免费抠图';
    card.querySelector('[data-action=crop]').hidden=p.mode!=='photo';
  });
}

function setStep(step){['#step-one','#step-partner','#step-two'].forEach((id,i)=>{const el=$(id);el.classList.toggle('active',i===step);el.classList.toggle('complete',i<step);if(i===step)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});}
function showPerson(i){
  activePerson=i;
  document.querySelectorAll('[data-card]').forEach((c,j)=>c.hidden=j!==i);
  $('#form-progress').textContent=`第 ${i+1} / 2 位`;
  $('#form-title').textContent=i===0?'先填写我的信息':'接着填写对方的信息';
  $('#form-guide').textContent=i===0?'换上我的头像和商品图，再填写这笔消费。也可以保留示例直接体验。':'换上对方的头像和商品图，再填写消费。填好后，一次生成两张图片。';
  $('#previous').hidden=i===0;
  $('#generate').textContent=i===0?'下一步：填对方 →':'生成两张图片 →';
  $('#next-hint').textContent=i===0?'填好后，继续填写对方的信息':'两个人都填好了，点击生成即可保存';
  setStep(i);
}
function focusError(i,e){showConfigure(i);toast(`${i===0?'我的':'对方的'}信息：${e.message}`);const card=$(`[data-card="${i}"]`);card.scrollIntoView({behavior:'smooth',block:'start'});const input=[...card.querySelectorAll('input[data-field]')].find(el=>!el.value.trim());input?.focus({preventScroll:true});}
function setBusy(index,busy,message=''){
  const card=$(`[data-card="${index}"]`);card.classList.toggle('is-busy',busy);
  card.querySelector('.processing').hidden=!busy;card.querySelector('.processing span').textContent=message;
  card.querySelectorAll('button').forEach(b=>b.disabled=busy&&b.dataset.action!=='cancel');
  $('#generate').disabled=busy;
}

async function processCutout(i){
  const p=people[i];if(busyPerson!==null)return toast('正在处理另一张商品图，请稍等');if(!p.image)return toast('请先上传商品图片');
  const source=p.image;busyPerson=i;setBusy(i,true,'准备识别商品…');
  try{
    const blob=await removeBackground(p.image.blob,message=>setBusy(i,true,message));
    const result=await trimTransparent(blob);
    if(source!==p.image||p!==people[i]){release(result);return;}
    release(p.cutout);p.cutout=result;p.mode='cutout';changed();toast('抠图完成，白边和阴影已添加');
  }catch(error){toast(error.message||'抠图失败，请重试');}
  finally{busyPerson=null;setBusy(i,false);render();}
}

async function upload(i,type,file){
  if(!file)return;if(busyPerson!==null)return toast('请先等待或取消正在进行的抠图');
  if(file.size>20*1024*1024)return toast('图片不能超过 20 MB，请压缩后再上传');
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))return toast('请上传 JPG、PNG 或 WebP 图片');
  const p=people[i];const version=resetVersion;
  try{
    const result=type==='cutout'?await trimTransparent(file):await decodedImage(file);
    if(version!==resetVersion||p!==people[i]){release(result);return;}
    if(type==='image'){release(p.image);release(p.cutout);p.image=result;p.cutout=null;p.zoom=1;p.x=p.y=50;}
    else{release(p[type]);p[type]=result;if(type==='cutout')p.mode='cutout';}
    changed();toast(type==='cutout'?'透明图片已更新':'图片已更新');
    if(type==='image'&&p.mode==='cutout')processCutout(i);
  }catch(error){toast(error.message);}
}

function bindCards(){
  document.querySelectorAll('[data-card]').forEach((card,i)=>{
    card.querySelectorAll('[data-field]').forEach(input=>{
      input.value=people[i][input.dataset.field];input.addEventListener('input',()=>{people[i][input.dataset.field]=input.type==='range'?Number(input.value):input.value;changed();});
      if(['amount','total'].includes(input.dataset.field))input.addEventListener('blur',()=>{try{input.value=people[i][input.dataset.field]=money(input.value);changed();}catch{}});
    });
    card.querySelectorAll('[data-file]').forEach(input=>input.addEventListener('change',()=>{upload(i,input.dataset.file,input.files[0]);input.value='';}));
    card.querySelectorAll('[data-mode]').forEach(button=>button.addEventListener('click',()=>{
      if(people[i].mode===button.dataset.mode)return;
      people[i].mode=button.dataset.mode;changed();if(people[i].mode==='cutout'&&!people[i].cutout)processCutout(i);
    }));
    card.querySelectorAll('[data-action]').forEach(button=>button.addEventListener('click',()=>{
      const action=button.dataset.action;
      if(['avatar','image','cutout'].includes(action))card.querySelector(`[data-file="${action}"]`).click();
      if(action==='remove')processCutout(i);
      if(action==='cancel')cancelRemoval();
      if(action==='crop'){
        cropIndex=i;$('#crop-zoom').value=people[i].zoom;$('#crop-x').value=people[i].x;$('#crop-y').value=people[i].y;
        drawWidget($('#crop-preview'),people[i],appearance);$('#crop-dialog').showModal();
      }
    }));
  });
}

async function restore(useStored=false){
  if(busyPerson!==null){toast('请先取消或完成正在进行的抠图');return;}
  const version=++resetVersion;$('#generate').disabled=true;$('#reset').disabled=true;
  const stored=useStored?readText():null;
  try{
    const next=await Promise.all(defaults.map(async(d,i)=>{
      const [image,avatar]=await Promise.all([d.imagePath,d.avatarPath].map(async path=>{const r=await fetch(path);if(!r.ok)throw new Error('示例图片加载失败，请刷新重试');return decodedImage(await r.blob());}));
      const values={...d};for(const key of ['name','category','amount','total','time'])if(typeof stored?.[i]?.[key]==='string')values[key]=stored[i][key].slice(0,30);
      return {...values,image,avatar,cutout:null,mode:'photo',zoom:1,x:50,y:50,size:1};
    }));
    if(version!==resetVersion)return;
    people.forEach(p=>{release(p.image);release(p.avatar);release(p.cutout);});people=next;
    $('#forms').innerHTML=[0,1].map(cardTemplate).join('');bindCards();changed();showConfigure(0);
  }catch(error){toast(error.message);}finally{$('#generate').disabled=false;$('#reset').disabled=false;}
}

function showConfigure(i=activePerson){$('#configure').hidden=false;$('#results').hidden=true;showPerson(i);}
function moveToPerson(i){showConfigure(i);$('#form-title').focus({preventScroll:true});window.scrollTo({top:0,behavior:'smooth'});}
async function nextStep(){
  if(people.length!==2)return toast('正在准备示例，请稍候');
  if(busyPerson!==null)return toast('正在抠图，请等待完成后继续');
  if(activePerson===0){try{validate(people[0]);}catch(e){return focusError(0,e);}moveToPerson(1);}
  else await generate();
}

async function generate(){
  if(people.length!==2)return toast('正在准备示例，请稍候');if(busyPerson!==null)return toast('请等待商品抠图完成');
  for(let i=0;i<2;i++){try{validate(people[i]);}catch(e){showConfigure();return focusError(i,e);}}
  const version=revision;$('#generate').disabled=true;clearResults();
  try{
    render();const blobs=await Promise.all(canvases.map(exportPng));if(version!==revision)return toast('内容已变化，请重新生成');
    resultFiles=blobs.map((blob,i)=>({blob,file:new File([blob],`${i===0?'我的':'对方的'}小组件.png`,{type:'image/png'}),url:URL.createObjectURL(blob)}));
    resultFiles.forEach((result,i)=>{
      const article=document.createElement('article');article.className='result-card';
      const h=document.createElement('h3');h.textContent=i===0?'我的小组件':'对方的小组件';
      const a=document.createElement('a');a.href=result.url;a.target='_blank';a.rel='noopener';a.className='preview-image-link';a.setAttribute('aria-label','打开'+h.textContent+'图片');
      const img=new Image();img.src=result.url;img.width=img.height=680;img.alt=people[i].name+'的消费小组件';a.append(img);
      const save=document.createElement('button');save.className='button primary';save.textContent=i===0?'保存我的图片 ↓':'保存对方图片 ↓';save.onclick=()=>saveImage(result);
      article.append(h,a,save);$('#result-grid').append(article);
    });
    $('#configure').hidden=true;$('#results').hidden=false;setStep(2);
    window.scrollTo({top:0,behavior:'smooth'});
  }catch(error){toast(error.message);}finally{$('#generate').disabled=false;}
}

function download(result){const a=document.createElement('a');a.href=result.url;a.download=result.file.name;document.body.append(a);a.click();a.remove();toast('已请求下载；App 内若没有响应，请点开图片长按保存');}
async function saveImage(result){
  if(navigator.canShare?.({files:[result.file]})){
    try{await navigator.share({files:[result.file]});return;}catch(e){if(e.name==='AbortError')return;}
  }download(result);
}

$('#generate').addEventListener('click',nextStep);
$('#previous').addEventListener('click',()=>moveToPerson(0));
$('#edit-me').addEventListener('click',()=>moveToPerson(0));$('#back').addEventListener('click',()=>moveToPerson(1));
$('#reset').addEventListener('click',()=>restore(false));
$('#outline').addEventListener('input',e=>{appearance.outline=Number(e.target.value);changed();});
$('#shadow').addEventListener('input',e=>{appearance.shadow=Number(e.target.value);changed();});
for(const [selector,key] of [['#crop-zoom','zoom'],['#crop-x','x'],['#crop-y','y']])$(selector).addEventListener('input',e=>{people[cropIndex][key]=Number(e.target.value);changed();drawWidget($('#crop-preview'),people[cropIndex],appearance);});
$('#share-all').addEventListener('click',async()=>{
  const files=resultFiles.map(x=>x.file);if(!files.length)return;
  if(navigator.canShare?.({files})){try{await navigator.share({files});}catch(e){if(e.name!=='AbortError')toast('分享未成功，请分别保存两张图片');}}
  else toast('当前浏览器不支持分享图片，请分别点击「保存图片」');
});
restore(true);
