import {removeBackground} from '@imgly/background-removal';
self.onmessage=async({data:{id,blob}})=>{
  try{
    self.postMessage({id,type:'progress',message:'正在加载免费抠图资源，首次使用约需下载 40 MB 模型…'});
    const result=await removeBackground(blob,{
      model:'isnet_quint8',device:'cpu',proxyToWorker:false,
      output:{format:'image/png',quality:1,type:'foreground'},
      progress:(key,current,total)=>{
        const message=current<total?`正在加载抠图资源 ${Math.round(current/total*100)}%`:'正在识别商品轮廓，请稍候…';
        self.postMessage({id,type:'progress',message});
      }
    });
    self.postMessage({id,type:'done',blob:result});
  }catch(error){self.postMessage({id,type:'error',message:'免费抠图资源加载或处理失败，请检查网络后重试，也可以上传已抠好的透明 PNG。'});}
};
