import test from 'node:test';
import assert from 'node:assert/strict';
import {example,schedule,snapshot,normalize,validate} from '../video/core.js';
test('消费时钟自动排期，双方累计和最近一笔由同一时间轴产生',()=>{
  const s=example();assert.equal(s.items[0].at,1);assert.equal(s.items.at(-1).at,13);
  assert.deepEqual(snapshot(s,0).sides.map(x=>x.total),[0,0]);
  const first=snapshot(s,1);assert.equal(first.clock,'08:00');assert.equal(first.sides[0].total,18);assert.equal(first.sides[0].latest.id,'sample-0');assert.equal(first.sides[1].latest,null);
  const end=snapshot(s,15);assert.equal(end.clock,'21:00');assert.deepEqual(end.sides.map(x=>x.total),[155.5,47.9]);
  s.items[0].clock='22:00';schedule(s);assert.equal(snapshot(s,15).sides[0].latest.id,'sample-0');
});
test('同时消费共同出现，空明细和同一时间不产生 NaN',()=>{
  const s=example();s.items=s.items.slice(0,2);s.items.forEach(x=>x.clock='12:00');schedule(s);
  assert.ok(s.items.every(x=>x.at===1));assert.deepEqual(snapshot(s,1).sides.map(x=>x.total),[18,12]);
  s.items=[];assert.deepEqual(snapshot(s,0).sides.map(x=>x.total),[0,0]);assert.equal(snapshot(s,0).clock,'07:00');
});
test('月对比期初和分类汇总保持金额精度，超过三个分类合并其他',()=>{
  const s=example();s.people[0].openingTotal='10.01';s.people[0].openingCount='2';
  s.items.filter(x=>x.side===0).forEach((x,i)=>{x.amount='0.1';x.category='分类'+i;});
  const a=snapshot(s,15).sides[0];assert.equal(a.monthTotal,10.51);assert.equal(a.count,7);
  assert.equal(a.rows.length,3);assert.equal(a.rows.reduce((n,x)=>n+Math.round(Number(x.amount)*100),0),1051);
});
test('手动秒数和消费时间独立，时长重排自动模式可稳定恢复',()=>{
  const s=example();s.timelineMode='manual';s.items[0].at=2;s.items[1].at=3;
  assert.equal(snapshot(s,2.5).clock,'08:00');assert.equal(snapshot(s,2.5).sides[1].total,0);
  s.timelineMode='clock';s.duration=30;schedule(s);assert.equal(s.items.at(-1).at,28);
  const clean=normalize({...s,unsafe:'ignored'});assert.equal(clean.unsafe,undefined);assert.equal(clean.templates[0],'small');
  clean.items[0].clock='25:00';assert.throws(()=>validate(clean),/消费时间/);
});
