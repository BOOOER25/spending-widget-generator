import test from 'node:test';
import assert from 'node:assert/strict';
import {example,schedule,snapshot,normalize,validate,hourTimeline,clockAt} from '../video/core.js';
test('消费时钟自动排期，双方累计和最近一笔由同一时间轴产生',()=>{
  const s=example(),firstAt=s.items[0].at;assert.ok(firstAt>0);
  assert.deepEqual(snapshot(s,0).sides.map(x=>x.total),[0,0]);
  const first=snapshot(s,firstAt);assert.equal(first.clock,'08:00');assert.equal(first.sides[0].total,18);assert.equal(first.sides[0].latest.id,'sample-0');assert.equal(first.sides[1].latest,null);
  const end=snapshot(s,15);assert.equal(end.clock,'23:00');assert.deepEqual(end.sides.map(x=>x.total),[155.5,47.9]);
  s.items[0].clock='22:00';schedule(s);assert.equal(snapshot(s,15).sides[0].latest.id,'sample-0');
});
test('同时消费共同出现，空明细和同一时间不产生 NaN',()=>{
  const s=example();s.items=s.items.slice(0,2);s.items.forEach(x=>x.clock='12:00');schedule(s);
  assert.ok(s.items.every(x=>x.at===s.items[0].at));assert.deepEqual(snapshot(s,s.items[0].at).sides.map(x=>x.total),[18,12]);
  s.items=[];assert.deepEqual(snapshot(s,0).sides.map(x=>x.total),[0,0]);assert.equal(snapshot(s,0).clock,'07:00');
});
test('月对比期初和分类汇总保持金额精度，超过三个分类合并其他',()=>{
  const s=example();s.people[0].openingTotal='10.01';s.people[0].openingCount='2';
  s.items.filter(x=>x.side===0).forEach((x,i)=>{x.amount='0.1';x.category='分类'+i;});
  const a=snapshot(s,15).sides[0];assert.equal(a.monthTotal,10.51);assert.equal(a.count,7);
  assert.equal(a.rows.length,3);assert.equal(a.rows.reduce((n,x)=>n+Math.round(Number(x.amount)*100),0),1051);
});
test('手动秒数和消费时间独立，时长重排自动模式可稳定恢复',()=>{
  const s=example();s.timelineMode='manual';s.items[0].at=2;s.items[1].at=3;
  assert.equal(snapshot(s,2.5).clock,'08:00');assert.equal(snapshot(s,2.5).sides[1].total,0);
  s.timelineMode='clock';s.duration=30;schedule(s);assert.ok(s.items.at(-1).at<29);
  const clean=normalize({...s,unsafe:'ignored'});assert.equal(clean.unsafe,undefined);assert.equal(clean.templates[0],'small');
  clean.items[0].clock='25:00';assert.throws(()=>validate(clean),/消费时间/);
});
test('每个小时保留相同时间槽，空小时不跳过，小时内保留分钟顺序',()=>{
  const s=example(),timeline=hourTimeline(s);
  assert.deepEqual(Array.from({length:17},(_,i)=>clockAt(s,timeline.opening+(i+.5)*timeline.slot)),Array.from({length:17},(_,i)=>`${String(7+i).padStart(2,'0')}:00`));
  assert.ok(s.items[1].at>s.items[0].at&&s.items[1].at<s.items[0].at+timeline.slot);
  assert.equal(clockAt(s,s.items[1].at),'08:00');
  s.items[0].clock='00:00';s.items[1].clock='23:59';s.duration=4;schedule(s);
  assert.equal(hourTimeline(s).startHour,0);
  assert.equal(clockAt(s,0),'00:00');assert.equal(clockAt(s,4),'23:00');
  assert.ok(s.items.every(x=>Number.isFinite(x.at)&&x.at<=s.duration-.5));
  const empty={...s,items:[]};assert.equal(clockAt(empty,empty.duration),'23:00');
});
test('时间开关独立保存，旧草稿默认显示时间，隐藏不改变排期或金额',()=>{
  const old=example();delete old.showTimes;const migrated=normalize(old);
  assert.deepEqual(migrated.showTimes,[true,true]);migrated.showTimes=[false,true];
  const restored=normalize(migrated);assert.deepEqual(restored.showTimes,[false,true]);
  assert.deepEqual(snapshot(old,old.duration),snapshot(restored,restored.duration));
});
