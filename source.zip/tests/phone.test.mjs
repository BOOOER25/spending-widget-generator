import test from 'node:test';
import assert from 'node:assert/strict';
import {DEVICES,resolution,constrain,placeDefault,snapWidget,hitRect} from '../phone-core.js';

test('screenshot resolution keeps exact pixels and rejects oversized or fractional canvases',()=>{
  assert.deepEqual(resolution('1206','2622'),{width:1206,height:2622});
  for(const [w,h] of [[0,2622],[1206.5,2622],[1206,''],[4096,8192],['NaN',2622]])assert.throws(()=>resolution(w,h));
  DEVICES.forEach(d=>assert.deepEqual(resolution(d.width,d.height),{width:d.width,height:d.height}));
});
test('initial widgets are square, separated and inside every preset screenshot',()=>{
  for(const screen of DEVICES){
    const a=placeDefault(0,screen,screen.ratio),b=placeDefault(1,screen,screen.ratio);
    const ar=hitRect(a,screen),br=hitRect(b,screen);
    assert.ok(ar.x+ar.size<br.x);assert.ok(ar.y>screen.height*.09);
    for(const r of [ar,br]){assert.ok(r.x>=0&&r.y>=0);assert.ok(r.x+r.size<=screen.width);assert.ok(r.y+r.size<=screen.height);}
  }
});
test('drag and resizing keep widgets in bounds, including landscape and captions',()=>{
  for(const screen of [{width:1206,height:2622},{width:1206,height:2622,caption:true},{width:1600,height:900,caption:true},{width:4096,height:320,caption:true}]){
    for(const x of [-1,0,.5,2])for(const y of [-1,0,.5,2]){
      const w=constrain({x,y,ratio:.4},screen),r=hitRect(w,screen);
      assert.ok(r.x>=0&&r.y>=0);assert.ok(r.x+r.size<=screen.width+1e-8);assert.ok(r.y+r.size+(screen.caption?screen.width*.05:0)<=screen.height+1e-8);
      const snapped=snapWidget(w,screen),sr=hitRect(snapped,screen);assert.ok(sr.x>=0&&sr.x+sr.size<=screen.width+1e-8);assert.ok(sr.y>=0&&sr.y+sr.size<=screen.height+1e-8);
    }
  }
});
