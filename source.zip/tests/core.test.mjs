import test from 'node:test';
import assert from 'node:assert/strict';
import {money,validate,coverRect} from '../core.js';
test('currency rejects blank, negative, exponent and excess precision',()=>{
  for(const value of ['', '-1','1e3','1.234','1000000','abc'])assert.throws(()=>money(value));
  assert.equal(money('0'),'0.00');assert.equal(money('999999.99'),'999999.99');
});
test('generation requires all information and the processed image in sticker mode',()=>{
  const p={name:'小鱼',category:'餐饮',amount:'30',total:'60',time:'11:24',image:{},avatar:{},mode:'photo'};
  assert.equal(validate(p),true);assert.throws(()=>validate({...p,mode:'cutout'}));assert.throws(()=>validate({...p,time:'25:12'}));assert.throws(()=>validate({...p,name:' '}));
  assert.equal(validate({...p,mode:'cutout',cutout:{}}),true);
});
test('crop remains covered at all slider positions, including portrait and landscape',()=>{
  for(const [iw,ih] of [[100,400],[400,100],[200,200]])for(const zoom of [1,2,3])for(const x of [0,50,100])for(const y of [0,50,100]){
    const r=coverRect(iw,ih,152,105,zoom,x,y);assert.ok(r.x<=0&&r.y<=0);assert.ok(r.x+r.w>=152-1e-8&&r.y+r.h>=105-1e-8);
  }
});
