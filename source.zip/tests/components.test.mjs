import test from 'node:test';
import assert from 'node:assert/strict';
import {example,normalize,snapshot} from '../video/core.js';
import {CATALOG,makeComponent,legacyComponents,componentBox,autoArrange,placeNewComponent,validateComponents,MAX_COMPONENTS} from '../video/components.js';
test('旧草稿迁移成独立实例，保留开关、数据归属、外观和原有位置',()=>{
  const old=example();delete old.components;old.showClock=false;old.templates=['fake','day'];
  old.widgetStyles[0]={corner:18,color:'#123abc',transparent:true};old.showTimes=[false,true];
  const next=normalize(old);assert.equal(next.components.length,4);
  assert.deepEqual(next.components.map(x=>x.type),['clock','total','fake','day']);
  assert.equal(next.components[0].visible,false);
  assert.equal(next.components[2].side,0);assert.equal(next.components[2].showTime,false);
  assert.deepEqual(next.components[2].style,old.widgetStyles[0]);
  assert.deepEqual(next.components,legacyComponents(old));
  assert.deepEqual(snapshot(next,15),snapshot(old,15));
});
test('中型对比和我/对方小型组件可并存，添加不替换已有实例',()=>{
  const s=example(),before=structuredClone(s.components);
  s.components=placeNewComponent(s.components,makeComponent('day',0,'day-one'));
  assert.equal(s.components.length,5);
  assert.deepEqual(s.components.slice(0,4),before);
  assert.deepEqual(s.components.filter(x=>x.type==='small').map(x=>x.side),[0,1]);
  assert.equal(normalize(s).components.at(-1).type,'day');
  const sum=snapshot(s,15).sides.map(x=>x.total);
  s.components.push(makeComponent('small',1,'extra-partner'));
  assert.deepEqual(snapshot(s,15).sides.map(x=>x.total),sum);
});
test('全部类型可自由组合，自动排版保留比例、不重叠且位于画布内',()=>{
  const list=CATALOG.map((x,i)=>makeComponent(x.type,x.side,'all-'+i));autoArrange(list);validateComponents(list);
  const boxes=list.map(componentBox);
  for(const r of boxes){assert.ok(r.x>=0&&r.y>=0&&r.x+r.w<=540.00001&&r.y+r.h<=960.00001);}
  for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){
    const a=boxes[i],b=boxes[j];
    assert.ok(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y));
  }
  const full=Array.from({length:MAX_COMPONENTS},(_,i)=>makeComponent('day',0,'full-'+i));
  assert.doesNotThrow(()=>validateComponents(autoArrange(full)));
});
test('空列表不恢复固定组件，独立设置保留，非法图层和越界数据被拒绝',()=>{
  const s=example();s.components=[];assert.deepEqual(normalize(s).components,[]);
  const a=makeComponent('small',0,'a'),b=makeComponent('small',0,'b');
  a.style.color='#aabbcc';a.showTime=false;b.style.transparent=true;
  s.components=[a,b];assert.deepEqual(normalize(s).components,[a,b]);
  b.id='a';assert.throws(()=>validateComponents(s.components),/重复/);
  b.id='b';b.x=540;assert.throws(()=>validateComponents(s.components),/超出/);
  b.x=0;b.type='__proto__';assert.throws(()=>validateComponents(s.components),/类型/);
});
