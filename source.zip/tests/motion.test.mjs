import test from 'node:test';
import assert from 'node:assert/strict';
import {example,snapshot,schedule} from '../video/core.js';
import {animatedSnapshot,tweenTrack,popPose,NUMBER_SECONDS,PRODUCT_SECONDS} from '../video/motion.js';
test('金额在触发点保持旧值，之后连续递增，结尾精确落到最终金额',()=>{
  const s=example(),at=s.items[0].at;
  assert.equal(animatedSnapshot(s,at-.001).sides[0].total,0);
  assert.equal(animatedSnapshot(s,at).sides[0].total,0);
  const values=[.05,.15,.3,.5,NUMBER_SECONDS].map(t=>animatedSnapshot(s,at+t).sides[0].total);
  assert.ok(values.every((v,i)=>v>0&&(i===0||v>values[i-1])));
  assert.equal(values.at(-1),18);
  const last=animatedSnapshot(s,s.duration);assert.deepEqual(last.sides.map(x=>x.total),snapshot(s,s.duration).sides.map(x=>x.total));
});
test('新记录从下方缩放弹出，轻微超调后准确落位',()=>{
  const first=popPose(0),middle=popPose(PRODUCT_SECONDS*.3),bounce=popPose(PRODUCT_SECONDS*.65),end=popPose(PRODUCT_SECONDS);
  assert.equal(first.alpha,0);assert.ok(first.y>=25&&first.scale<.8);
  assert.ok(middle.alpha===1&&middle.y<first.y&&middle.scale>first.scale);
  assert.ok(bounce.scale>1&&bounce.scale<1.04);
  assert.deepEqual(end,{y:0,scale:1,alpha:1});
});
test('新金额打断正在进行的变化不会跳值，任意反向拖动可确定性重现',()=>{
  const track=[{at:1,value:100},{at:1.2,value:500}];
  assert.ok(Math.abs(tweenTrack(track,0,1.2-1e-7)-tweenTrack(track,0,1.2))<.001);
  const s=example();s.timelineMode='manual';s.items[0].at=1;s.items[2].at=1.1;
  const frame=animatedSnapshot(s,1.17);animatedSnapshot(s,15);animatedSnapshot(s,0);
  assert.deepEqual(animatedSnapshot(s,1.17),frame);
  assert.ok(Math.abs(animatedSnapshot(s,1.1-1e-7).sides[0].total-animatedSnapshot(s,1.1).sides[0].total)<=.01);
});
test('商品保留上一笔用于过渡，同时消费以同一组完成更新',()=>{
  const s=example(),third=s.items[2],at=third.at;
  const start=animatedSnapshot(s,at).sides[0];assert.equal(start.motion.previous.id,'sample-0');assert.equal(start.motion.progress,0);
  const middle=animatedSnapshot(s,at+PRODUCT_SECONDS/2).sides[0];assert.ok(middle.motion.progress>0&&middle.motion.progress<1);
  assert.equal(animatedSnapshot(s,at+PRODUCT_SECONDS).sides[0].motion.productChanging,false);
  s.items[0].clock=s.items[2].clock;schedule(s);
  const grouped=animatedSnapshot(s,s.items[2].at+.1).sides[0];assert.equal(grouped.motion.gain,50.5);
});
test('月分类和期初金额完成后与逻辑结果一致，其他分类不会遗漏',()=>{
  const s=example();s.people[0].openingTotal='10.01';s.people[0].openingCount='2';
  s.items.filter(x=>x.side===0).forEach((x,i)=>{x.category=i===0?'其他':'分类'+i;});
  const end=animatedSnapshot(s,s.duration).sides[0],expected=snapshot(s,s.duration).sides[0];
  assert.equal(end.monthTotal,expected.monthTotal);assert.deepEqual(end.rows.map(({barRatio,...row})=>row),expected.rows);
  for(let t=0;t<=15;t+=.07){const a=animatedSnapshot(s,t).sides[0];if(a.rows.filter(x=>x.name!=='—').length===3)assert.ok(Math.abs(a.rows.reduce((v,r)=>v+Number(r.amount),0)-a.monthTotal)<.025);}
  s.items=[];const empty=animatedSnapshot(s,0).sides[0];assert.equal(empty.total,0);assert.equal(empty.monthTotal,10.01);
});
test('首笔消费的百分比和月分类条逐帧生长，不因归一化一帧跳满',()=>{
  const s=example();s.items=s.items.slice(0,1);const at=s.items[0].at;
  assert.equal(animatedSnapshot(s,at).sides[0].ratio,0);
  const half=animatedSnapshot(s,at+.18).sides[0],end=animatedSnapshot(s,at+NUMBER_SECONDS).sides[0];
  assert.ok(half.ratio>0&&half.ratio<end.ratio);
  assert.ok(half.rows[0].barRatio>0&&half.rows[0].barRatio<end.rows[0].barRatio);
  assert.equal(animatedSnapshot(s,s.duration).sides.reduce((n,x)=>n+x.ratio,0),1);
});
