import test from 'node:test';
import assert from 'node:assert/strict';
import {constrain,hitRect,layoutWidgets} from '../phone-core.js';
import {validate} from '../core.js';
import {TEMPLATES,defaultComparison} from '../templates.js';
test('medium template geometry stays 966:444 through resize and layout',()=>{
 const screen={width:1080,height:2340,caption:true};
 const medium={ratio:TEMPLATES.day.ratio,aspect:966/444,visible:true,x:0,y:0};
 const small={ratio:TEMPLATES.small.ratio,aspect:1,visible:true,x:0,y:0};
 for(const list of [[medium,small],[small,medium],[medium,medium]]){
   const result=layoutWidgets(list,screen),[a,b]=result.map(w=>hitRect(w,screen));
   assert.ok(a.y+a.height+screen.width*.05<=b.y+1e-8);
   for(const w of result){const r=hitRect(constrain({...w,x:2,y:2},screen),screen);assert.ok(Math.abs(r.width/r.height-w.aspect)<1e-8);assert.ok(r.x+r.width<=screen.width+1e-8);assert.ok(r.y+r.height+54<=screen.height+1e-8);}
 }
});
test('real templates validate fields they actually render',()=>{
 const cmp={template:'day',comparison:defaultComparison()};assert.equal(validate(cmp),true);
 cmp.comparison.left.total='-1';assert.throws(()=>validate(cmp));
 const monthly={template:'month',comparison:defaultComparison()};assert.equal(validate(monthly),true);
 monthly.comparison.right.rows[2].amount='bad';assert.throws(()=>validate(monthly));
 assert.equal(validate({template:'small',amount:'17.61',category:'餐饮',time:'07:23',image:{},avatar:{},mode:'photo'}),true);
 assert.throws(()=>validate({template:'small',amount:'17.61',category:'',time:'07:23',image:{},avatar:{},mode:'photo'}));
 assert.throws(()=>validate({...cmp,templateLoading:true}));
});
