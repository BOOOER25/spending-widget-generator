export const config={provider:'local',apiUrl:''};
