export function money(value) {
  const s = String(value).trim();
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(s)) throw new Error('金额请输入 0–999999.99，最多两位小数');
  return Number(s).toFixed(2);
}

export function validate(person) {
  if (!person.name.trim()) throw new Error('请填写 ID');
  if (!person.category.trim()) throw new Error('请填写分类');
  money(person.amount); money(person.total);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(person.time)) throw new Error('请选择消费时间');
  if (!person.image) throw new Error('请上传商品图片');
  if (!person.avatar) throw new Error('请上传头像');
  if (person.mode === 'cutout' && !person.cutout) throw new Error('请先完成商品抠图，或切换为保留原图');
  return true;
}

export function coverRect(iw, ih, width, height, zoom=1, x=50, y=50) {
  const scale = Math.max(width/iw,height/ih) * zoom;
  const w=iw*scale,h=ih*scale;
  return {x:(width-w)*x/100,y:(height-h)*y/100,w,h};
}

export function clippedText(ctx, value, width) {
  const chars=Array.from(value);
  if(ctx.measureText(value).width<=width) return value;
  while(chars.length && ctx.measureText(chars.join('')+'…').width>width) chars.pop();
  return chars.join('')+'…';
}
