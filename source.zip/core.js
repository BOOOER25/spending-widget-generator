export function money(value) {
  const s = String(value).trim();
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(s)) throw new Error('金额请输入 0–999999.99，最多两位小数');
  return Number(s).toFixed(2);
}

export function validate(person) {
  if(person.templateLoading)throw new Error('请等待样式素材加载完成');
  if(person.templateError)throw new Error('样式素材加载失败，请先重试');
  if(person.template==='day'||person.template==='month'){
    const cmp=person.comparison;if(!cmp)throw new Error('请填写对比数据');
    if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(cmp.updated))throw new Error('请填写有效的数据更新时间');
    for(const side of ['left','right']){const s=cmp[side];if(person.template==='day'){if(!s.name.trim())throw new Error('请填写双方显示名称');money(s.total);money(s.latestAmount);if(!s.category.trim())throw new Error('请填写最近一笔消费的分类');if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time))throw new Error('请填写有效的消费时间');}
      else {money(s.monthTotal);if(!/^\d{1,4}$/.test(String(s.count)))throw new Error('消费笔数请输入 0–9999 的整数');if(s.rows.length!==3)throw new Error('请填写三个分类');for(const row of s.rows){if(!row.name.trim())throw new Error('请填写分类名称');money(row.amount);}}}
    return true;
  }
  if(person.template==='small'){
    money(person.amount);if(!person.category.trim())throw new Error('请填写分类');if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(person.time))throw new Error('请填写有效的消费时间');
    if(!person.image)throw new Error('请上传商品图片');if(!person.avatar)throw new Error('请上传头像');if(person.mode==='cutout'&&!person.cutout)throw new Error('请先完成抠图或切换为保留原图');return true;
  }

  if (!person.name.trim()) throw new Error('请填写名称');
  money(person.amount); money(person.total);
  if (!person.image) throw new Error('请上传商品图片');
  if (!person.avatar) throw new Error('请上传头像');
  if (person.mode === 'cutout' && !person.cutout) throw new Error('请先完成商品抠图，或切换为保留原图');
  return true;
}

export function coverRect(iw, ih, width, height, zoom=1, x=50, y=50) {
  const scale = Math.max(width/iw,height/ih) * zoom;
  const w=iw*scale,h=ih*scale;
  return {x:(width-w)*x/100,y:(height-h)*y/100,w,h};
}

export function clippedText(ctx, value, width) {
  const chars=Array.from(value);
  if(ctx.measureText(value).width<=width) return value;
  while(chars.length && ctx.measureText(chars.join('')+'…').width>width) chars.pop();
  return chars.join('')+'…';
}
