export const MAX_COMPONENTS=16;
export const COMPONENT_TYPES={
  clock:{name:'当前时间',ratio:200/64,width:200},
  total:{name:'今日消费总对比',ratio:500/94,width:500},
  small:{name:'真小型组件',ratio:1,width:238},
  fake:{name:'假小型组件',ratio:1,width:238},
  day:{name:'中型双方消费对比',ratio:322/148,width:484},
  month:{name:'中型本月消费对比',ratio:322/148,width:484},
};
export const CATALOG=[
  {type:'clock',side:0,name:'当前时间'},{type:'total',side:0,name:'今日消费总对比'},
  {type:'small',side:0,name:'真小型 · 我的上一笔'},{type:'small',side:1,name:'真小型 · 对方上一笔'},
  {type:'fake',side:0,name:'假小型 · 我的上一笔'},{type:'fake',side:1,name:'假小型 · 对方上一笔'},
  {type:'day',side:0,name:'中型 · 双方今日消费对比'},{type:'month',side:0,name:'中型 · 本月消费对比'},
];
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
export const isWidget=c=>['small','fake','day','month'].includes(c.type);
export const isPersonal=c=>c.type==='small'||c.type==='fake';
export function componentName(c){
  return COMPONENT_TYPES[c.type].name+(isPersonal(c)?` · ${c.side?'对方':'我'}的上一笔`:'');
}
export function makeComponent(type,side=0,id=crypto.randomUUID()){
  const def=COMPONENT_TYPES[type];if(!def)throw Error('组件类型无效');
  return {id,type,side,x:(540-def.width)/2,y:329,width:def.width,visible:true,showTime:true,showLabel:isWidget({type}),imageMode:'inherit',
    style:{corner:type==='clock'?0:type==='total'?24:12,color:type==='clock'?'#252936':type==='total'?'#ffffff':side?'#b7e8d4':'#ffdc67',transparent:type==='clock'}};
}
export function componentBox(c){return {x:c.x,y:c.y,w:c.width,h:c.width/COMPONENT_TYPES[c.type].ratio};}
export function fitComponent(c){
  c.width=clamp(c.width,32,540);
  const h=c.width/COMPONENT_TYPES[c.type].ratio;
  c.x=clamp(c.x,0,540-c.width);c.y=clamp(c.y,c.showLabel?26:0,960-h);
  return c;
}
export function legacyWidgetLayout(templates){
  const medium=t=>t==='day'||t==='month';
  if(!templates.some(medium))return templates.map((t,i)=>({x:26+i*250,y:329,w:238,h:238,template:t}));
  const sizes=templates.map(t=>medium(t)?{w:484,h:484*148/322}:{w:222,h:222});
  const total=sizes[0].h+sizes[1].h+62,top=316+(540-total)/2;
  return sizes.map((r,i)=>({...r,x:(540-r.w)/2,y:top+(i?sizes[0].h+62:0),template:templates[i]}));
}
export function legacyComponents(s){
  const clock={...makeComponent('clock',0,'legacy-clock'),x:170,y:107,visible:s.showClock!==false};
  const total={...makeComponent('total',0,'legacy-total'),x:20,y:183};
  return [clock,total,...legacyWidgetLayout(s.templates||['small','small']).map((r,i)=>({
    ...makeComponent(r.template,i,'legacy-widget-'+i),x:r.x,y:r.y,width:r.w,showTime:s.showTimes?.[i]!==false,
    style:{...(s.widgetStyles?.[i]||makeComponent(r.template,i).style)},
  }))];
}
export const sceneComponents=s=>Array.isArray(s.components)?s.components:legacyComponents(s);
export function normalizeComponents(raw){
  if(!Array.isArray(raw))throw Error('组件列表无效');
  return raw.map(c=>({
    id:c?.id,type:c?.type,side:c?.side,x:c?.x,y:c?.y,width:c?.width,
    visible:c?.visible,showTime:c?.showTime,showLabel:c?.showLabel,imageMode:c?.imageMode??'inherit',
    style:{corner:c?.style?.corner,color:typeof c?.style?.color==='string'?c.style.color.toLowerCase():'',transparent:c?.style?.transparent},
  }));
}
export function validateComponents(list){
  if(!Array.isArray(list)||list.length>MAX_COMPONENTS)throw Error(`最多添加 ${MAX_COMPONENTS} 个组件`);
  const ids=new Set();
  for(const c of list){
    if(!c||typeof c.id!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(c.id)||ids.has(c.id))throw Error('组件编号无效或重复');
    ids.add(c.id);
    if(!Object.hasOwn(COMPONENT_TYPES,c.type)||![0,1].includes(c.side))throw Error('组件类型或消费归属无效');
    if(![c.x,c.y,c.width].every(Number.isFinite)||c.width<32||c.width>540)throw Error('组件位置或大小无效');
    const r=componentBox(c);
    if(r.x<0||r.y<0||r.x+r.w>540.00001||r.y+r.h>960.00001)throw Error('组件超出画布，请调整位置或大小');
    if([c.visible,c.showTime,c.showLabel].some(v=>typeof v!=='boolean'))throw Error('组件显示设置无效');
    if(!['inherit','photo','cutout'].includes(c.imageMode))throw Error('组件商品展示方式无效');
    const p=c.style;
    if(!p||!Number.isFinite(p.corner)||p.corner<0||p.corner>25||!/^#[0-9a-f]{6}$/i.test(p.color)||typeof p.transparent!=='boolean')throw Error('圆角需为 0–25%，颜色需为六位色值');
  }
  return list;
}
export function autoArrange(list){
  const visible=list.filter(c=>c.visible),rows=[];
  for(let i=0;i<visible.length;i++){
    const c=visible[i],row=[c];
    if(isPersonal(c)&&visible[i+1]&&isPersonal(visible[i+1]))row.push(visible[++i]);
    rows.push(row);
  }
  const specs=rows.map(row=>{
    const widths=row.map(c=>COMPONENT_TYPES[c.type].width);
    return {row,widths,label:row.some(c=>c.showLabel)?28:0,h:Math.max(...row.map((c,i)=>widths[i]/COMPONENT_TYPES[c.type].ratio))};
  });
  const gap=20,available=814,total=specs.reduce((n,r)=>n+r.h+r.label,0);
  const k=Math.min(1,(available-gap*Math.max(0,rows.length-1))/Math.max(1,total));
  let y=70;
  for(const spec of specs){
    y+=spec.label*k;
    const widths=spec.widths.map(w=>w*k),pair=spec.row.length===2,totalWidth=widths.reduce((a,b)=>a+b,0)+(pair?24*k:0);
    let x=(540-totalWidth)/2;
    spec.row.forEach((c,i)=>{c.width=widths[i];c.x=x;c.y=y;fitComponent(c);x+=widths[i]+24*k;});
    y+=spec.h*k+gap;
  }
  return list;
}
export function placeNewComponent(list,c){
  const bounds=x=>{const r=componentBox(x),label=x.showLabel?26:0;return {x:r.x,y:r.y-label,w:r.w,h:r.h+label};};
  const overlaps=(a,b)=>a.x<b.x+b.w+12&&a.x+a.w+12>b.x&&a.y<b.y+b.h+12&&a.y+a.h+12>b.y;
  for(let y=80;y+componentBox(c).h<=890;y+=12){
    const candidates=isPersonal(c)?[26,276,(540-c.width)/2]:[(540-c.width)/2];
    for(const x of candidates){
      c.x=x;c.y=y;fitComponent(c);
      if(!list.filter(v=>v.visible).some(v=>overlaps(bounds(c),bounds(v))))return [...list,c];
    }
  }
  return autoArrange([...list,c]);
}
