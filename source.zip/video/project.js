export const project={id:'widget-video-studio',title:'小组件视频',subtitle:'每一笔消费，随着时间更新到小组件。',variant:'widgets'};
