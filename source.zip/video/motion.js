import {snapshot,clamp,cents} from './core.js';
export const NUMBER_SECONDS=.62,PRODUCT_SECONDS=.58,GAIN_SECONDS=.9;
export const easeOut=p=>1-(1-clamp(p,0,1))**3;
export function popPose(age,distance=26){
  const p=clamp(age/PRODUCT_SECONDS,0,1),q=p-1;
  const spring=1+2.70158*q*q*q+1.70158*q*q;
  return {y:distance*(1-easeOut(p)),scale:.72+.28*spring,alpha:clamp(age/.08,0,1)};
}

// Evaluate from timeline time, never from the last painted frame. Seeking and
// recording therefore get identical motion, including interruptions by new orders.
export function tweenTrack(events,initial,time,duration=NUMBER_SECONDS){
  let from=initial,to=initial,at=-Infinity;
  for(const event of events){
    if(event.at>time+1e-7)break;
    const current=Number.isFinite(at)?from+(to-from)*easeOut((event.at-at)/duration):to;
    from=current;to=event.value;at=event.at;
  }
  return Number.isFinite(at)?from+(to-from)*easeOut((time-at)/duration):initial;
}
const money=n=>Math.round(n)/100;
function rowKey(side,row,index,opening){
  const count=new Set([...side.items.map(x=>x.category||'其他'),...(opening>0?['此前消费']:[])]).size;
  return count>3&&index===2?'__remainder':row.name;
}
export function createMotionTracks(s){
  const ratios=[[],[]],bars=[new Map(),new Map()];
  for(const at of [...new Set(s.items.map(x=>x.at))].sort((a,b)=>a-b)){
    const snap=snapshot(s,at),total=snap.sides[0].total+snap.sides[1].total;
    snap.sides.forEach((side,i)=>{
      ratios[i].push({at,value:total?side.total/total:0});
      const max=Math.max(1,...side.rows.map(x=>Number(x.amount)))*1.2;
      const active=new Map(side.rows.map((row,j)=>[rowKey(side,row,j,cents(s.people[i].openingTotal)),Number(row.amount)/max]));
      for(const key of new Set([...bars[i].keys(),...active.keys()])){
        if(!bars[i].has(key))bars[i].set(key,[]);
        bars[i].get(key).push({at,value:active.get(key)||0});
      }
    });
  }
  // Existing month data is present from the opening frame, before any purchases.
  const initial=snapshot(s,-1e-5);
  initial.sides.forEach((side,i)=>{
    const max=Math.max(1,...side.rows.map(x=>Number(x.amount)))*1.2;
    side.rows.forEach((row,j)=>{
      const key=rowKey(side,row,j,cents(s.people[i].openingTotal));
      if(!bars[i].has(key))bars[i].set(key,[]);
      bars[i].get(key).unshift({at:-NUMBER_SECONDS,value:Number(row.amount)/max});
    });
  });
  return {ratios,bars};
}
export function animatedSnapshot(s,time,tracks=createMotionTracks(s)){
  const target=snapshot(s,time),all=[...s.items].sort((a,b)=>a.at-b.at||a.clock.localeCompare(b.clock));
  const sides=target.sides.map((side,index)=>{
    const orders=all.filter(x=>x.side===index),amounts=[],categories=new Map();
    let animatedCents=0;
    for(const item of orders){
      amounts.push({at:item.at,value:cents(item.amount)});
      if(item.at>time+1e-7)continue;
      const value=cents(item.amount)*easeOut((time-item.at)/NUMBER_SECONDS);
      animatedCents+=value;
      const key=item.category||'其他';categories.set(key,(categories.get(key)||0)+value);
    }
    const opening=cents(s.people[index].openingTotal),total=money(animatedCents),latest=side.latest;
    const previous=latest?orders.filter(x=>x.at<latest.at-1e-7).at(-1)||null:null;
    const age=latest?Math.max(0,time-latest.at):Infinity;
    const progress=Number.isFinite(age)?easeOut(age/PRODUCT_SECONDS):1;
    const group=side.items.filter(x=>latest&&Math.abs(x.at-latest.at)<1e-7);
    const categoryCount=new Set([...side.items.map(x=>x.category||'其他'),...(opening>0?['此前消费']:[])]).size;
    const rows=side.rows.map((row,i)=>{
      const barRatio=tweenTrack(tracks.bars[index].get(rowKey(side,row,i,opening))||[],0,time);
      if(row.name==='—')return {...row,barRatio};
      return {...row,barRatio,amount:money((categories.get(row.name)||0)+(row.name==='此前消费'?opening:0)).toFixed(2)};
    });
    if(categoryCount>3)rows[2].amount=money(Math.round(opening+animatedCents)-cents(rows[0].amount)-cents(rows[1].amount)).toFixed(2);
    return {...side,total,monthTotal:money(opening+animatedCents),ratio:tweenTrack(tracks.ratios[index],0,time),
      latestAmount:money(tweenTrack(amounts,0,time)),rows,
      motion:{age,progress,previous,
        changing:!!latest&&age<NUMBER_SECONDS-1e-7,
        productChanging:!!latest&&age<PRODUCT_SECONDS-1e-7,
        gain:group.reduce((n,x)=>n+cents(x.amount),0)/100,
        gainOpacity:Number.isFinite(age)&&age<GAIN_SECONDS?Math.sin(Math.PI*clamp(age/GAIN_SECONDS,0,1)):0}};
  });
  return {...target,sides};
}
