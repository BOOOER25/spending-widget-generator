import {CATALOG,MAX_COMPONENTS,makeComponent,componentName,componentBox,isWidget,isPersonal,fitComponent,placeNewComponent,autoArrange} from './components.js';
import {loadTemplateAssets} from '../templates.js';
const $=s=>document.querySelector(s);
function element(tag,attrs={},text){
  const n=document.createElement(tag);
  for(const [key,value] of Object.entries(attrs)){if(key==='class')n.className=value;else n.setAttribute(key,value);}
  if(text!==undefined)n.textContent=text;return n;
}
export function createComponentEditor({getState,getTime,renderer,edit,prepare,pause,toast}){
  let selectedId,active=true,catalogReady=false,lastThumb=0,drag=null;
  const overlay=$('#component-overlay'),overlayButtons=new Map(),thumbs=new Map(),catalogThumbs=[];
  const selected=()=>getState().components.find(c=>c.id===selectedId);
  function apply(change,{rebuild=true,assets=false}={}){
    if(!edit(()=>change(getState()))){sync();return;}
    sync(rebuild);if(assets)prepare();
  }
  function choose(id){pause();selectedId=id;sync();}
  function field(parent,label,control){const wrap=element('label',{},label);wrap.append(control);parent.append(wrap);return control;}
  function select(parent,label,values,value,change){
    const input=element('select',{'aria-label':label});
    values.forEach(([v,name])=>input.append(element('option',{value:v},name)));
    input.value=String(value);input.addEventListener('change',()=>change(input.value));return field(parent,label,input);
  }
  function number(parent,label,value,change,attrs={}){
    const input=element('input',{type:'number','aria-label':label,...attrs});input.value=value;
    input.addEventListener('change',()=>change(Number(input.value)));return field(parent,label,input);
  }
  function button(label,action,attrs={}){const b=element('button',{type:'button',...attrs},label);b.addEventListener('click',action);return b;}
  function updateInspector(){
    const c=selected();if(!c)return;
    const values={width:Math.round(c.width/540*1000)/10,x:Math.round(c.x/540*1000)/10,y:Math.round(c.y/960*1000)/10,corner:c.style.corner,color:c.style.color};
    for(const input of $('#component-inspector').querySelectorAll('[data-prop]')){
      input.value=values[input.dataset.prop];
      if(input.dataset.prop==='color')input.disabled=c.type!=='clock'&&c.style.transparent;
    }
    const out=$('#component-inspector output');if(out)out.textContent=c.style.corner+'%';
  }
  function inspector(){
    const host=$('#component-inspector');host.replaceChildren();const c=selected();host.hidden=!c;if(!c)return;
    const title=element('div',{class:'inspector-heading'});title.append(element('h3',{},componentName(c)),button('删除',()=>{
      const id=c.id;selectedId=null;apply(s=>s.components=s.components.filter(x=>x.id!==id),{assets:true});
    },{'aria-label':'删除所选组件',class:'quiet'}));host.append(title);
    if(isPersonal(c)){
      select(host,'消费归属',[['0','我的上一笔'],['1','对方的上一笔']],c.side,v=>apply(()=>c.side=Number(v)));
      select(host,'商品展示方式',[['inherit','跟随画面设置'],['photo','保留原图'],['cutout','透明贴纸']],c.imageMode,v=>apply(()=>c.imageMode=v));
    }
    const geometry=element('div',{class:'field-grid'});
    const width=number(geometry,'宽度（%）',0,v=>apply(()=>{c.width=v/100*540;fitComponent(c);}),{min:6,max:100,step:.5});width.dataset.prop='width';
    const x=number(geometry,'水平位置（%）',0,v=>apply(()=>{c.x=v/100*540;fitComponent(c);}),{min:0,max:100,step:.5});x.dataset.prop='x';
    const y=number(geometry,'垂直位置（%）',0,v=>apply(()=>{c.y=v/100*960;fitComponent(c);}),{min:0,max:100,step:.5});y.dataset.prop='y';host.append(geometry);
    if(isWidget(c)){
      select(host,'显示组件名称',[['true','显示'],['false','隐藏']],c.showLabel,v=>apply(()=>{c.showLabel=v==='true';fitComponent(c);}));
      if(c.type!=='fake')select(host,'组件内时间',[['true','显示时间'],['false','隐藏时间']],c.showTime,v=>apply(()=>c.showTime=v==='true'));
    }
    if(c.type!=='clock'){
      const wrap=element('label',{},'圆角 '),out=element('output',{},c.style.corner+'%'),range=element('input',{type:'range',min:0,max:25,step:1,'aria-label':'所选组件圆角','data-prop':'corner'});
      range.value=c.style.corner;range.addEventListener('input',()=>apply(()=>c.style.corner=Number(range.value),{rebuild:false}));wrap.append(out,range);host.append(wrap);
      select(host,'外底',[['false','指定颜色'],['true','透明']],c.style.transparent,v=>apply(()=>c.style.transparent=v==='true'));
    }
    const row=element('span',{class:'style-color-row'}),palette=element('input',{type:'color','aria-label':c.type==='clock'?'文字颜色':'外底颜色','data-prop':'color'}),
      hex=element('input',{type:'text',maxlength:7,spellcheck:'false','aria-label':'所选组件颜色色值','data-prop':'color'});
    palette.addEventListener('input',()=>apply(()=>c.style.color=palette.value,{rebuild:false}));
    hex.addEventListener('change',()=>apply(()=>c.style.color=hex.value.trim().toLowerCase()));
    row.append(palette,hex);field(host,c.type==='clock'?'文字颜色':'外底颜色',row);
    const actions=element('div',{class:'component-actions'});
    actions.append(button('复制一份',()=>{
      if(getState().components.length>=MAX_COMPONENTS)return toast(`最多添加 ${MAX_COMPONENTS} 个组件`);
      const copy=structuredClone(c);copy.id=crypto.randomUUID();copy.x+=12;copy.y+=12;fitComponent(copy);selectedId=copy.id;
      apply(s=>s.components.push(copy),{assets:true});
    }),button('置于顶层',()=>apply(s=>{s.components=s.components.filter(x=>x.id!==c.id);s.components.push(c);})),
      button('置于底层',()=>apply(s=>{s.components=s.components.filter(x=>x.id!==c.id);s.components.unshift(c);})));
    host.append(actions);updateInspector();
  }
  function paintOverlay(){
    const list=getState().components.filter(c=>c.visible),ids=new Set(list.map(c=>c.id));
    for(const [id,b] of overlayButtons)if(!ids.has(id)){b.remove();overlayButtons.delete(id);}
    for(const [index,c] of list.entries()){
      let b=overlayButtons.get(c.id);
      if(!b){
        b=element('button',{class:'canvas-component',type:'button'});overlayButtons.set(c.id,b);
        b.addEventListener('pointerdown',e=>{
          if(e.button!==0)return;
          e.preventDefault();choose(c.id);
          const current=selected(),rect=overlay.getBoundingClientRect();
          drag={id:c.id,pointer:e.pointerId,x:e.clientX,y:e.clientY,fromX:current.x,fromY:current.y,w:rect.width,h:rect.height};
          b.setPointerCapture(e.pointerId);
        });
        b.addEventListener('pointermove',e=>{
          if(!drag||drag.id!==c.id||drag.pointer!==e.pointerId)return;
          const d=drag;
          edit(()=>{const current=getState().components.find(x=>x.id===d.id);if(current){current.x=d.fromX+(e.clientX-d.x)/d.w*540;current.y=d.fromY+(e.clientY-d.y)/d.h*960;fitComponent(current);}});
          updateInspector();
        });
        const end=e=>{if(drag?.pointer===e.pointerId){drag=null;sync(false);}};
        b.addEventListener('pointerup',end);b.addEventListener('pointercancel',end);
        b.addEventListener('click',()=>{if(selectedId!==c.id)choose(c.id);});
        b.addEventListener('keydown',e=>{
          if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
          e.preventDefault();apply(s=>{const current=s.components.find(x=>x.id===c.id);current.x+=e.key==='ArrowRight'?2:e.key==='ArrowLeft'?-2:0;current.y+=e.key==='ArrowDown'?2:e.key==='ArrowUp'?-2:0;fitComponent(current);},{rebuild:false});
        });
      }
      const r=componentBox(c);b.style.left=r.x/540*100+'%';b.style.top=r.y/960*100+'%';b.style.width=r.w/540*100+'%';b.style.height=r.h/960*100+'%';
      b.classList.toggle('selected',c.id===selectedId);b.setAttribute('aria-label','选择 '+componentName(c));b.title=componentName(c)+'，拖动调整位置';
      if(overlay.children[index]!==b)overlay.insertBefore(b,overlay.children[index]||null);
    }
    overlay.hidden=!active;
  }
  function paintThumbs(force=false){
    if(!force&&performance.now()-lastThumb<160)return;lastThumb=performance.now();
    const s=getState(),time=getTime();
    for(const [id,canvas] of thumbs){const c=s.components.find(c=>c.id===id);if(c)renderer.preview(canvas,s,c,time);}
    if(!$('#component-menu').hidden&&catalogReady)for(const {component,canvas} of catalogThumbs)renderer.preview(canvas,s,component,time);
  }
  function sync(rebuild=true){
    const s=getState();if(!s.components.some(c=>c.id===selectedId))selectedId=s.components[0]?.id;
    $('#component-count').textContent=s.components.length;
    $('#add-component').disabled=s.components.length>=MAX_COMPONENTS;
    const list=$('#component-list');list.replaceChildren();thumbs.clear();
    for(const c of s.components){
      const row=element('article',{class:'component-row','data-component-id':c.id});row.classList.toggle('selected',c.id===selectedId);row.classList.toggle('muted',!c.visible);
      const pick=button('',()=>choose(c.id),{class:'component-pick','aria-label':'配置 '+componentName(c)});
      const thumb=element('span',{class:'component-thumb'}),canvas=element('canvas');thumb.append(canvas);thumbs.set(c.id,canvas);
      const words=element('span',{class:'component-row-text'});words.append(element('strong',{},componentName(c)),element('span',{},c.visible?'已显示 · 点击配置':'已隐藏'));
      pick.append(thumb,words);
      const visibility=button(c.visible?'隐藏':'显示',()=>apply(()=>c.visible=!c.visible,{assets:true}),{'aria-label':(c.visible?'隐藏 ':'显示 ')+componentName(c),class:'quiet'});
      row.append(pick,visibility);list.append(row);
    }
    $('#components-empty').hidden=s.components.length>0;
    if(rebuild)inspector();else updateInspector();
    paintOverlay();paintThumbs(true);
  }
  async function openMenu(){
    const menu=$('#component-menu');menu.hidden=false;$('#add-component').setAttribute('aria-expanded','true');
    catalogReady=false;$('#catalog-status').textContent='正在准备当前时刻的组件预览…';
    for(const b of menu.querySelectorAll('[data-add-type]'))b.disabled=true;
    const kinds=['small','day','month'],results=await Promise.allSettled(kinds.map(loadTemplateAssets));
    const failed=new Set(kinds.filter((_,i)=>results[i].status==='rejected'));catalogReady=true;
    $('#catalog-status').textContent=failed.size?'部分预览加载失败，其余组件可正常添加；关闭后重新打开可重试。':'预览使用当前进度的数据。点选一个，即可添加到画面。';
    for(const b of menu.querySelectorAll('[data-add-type]'))b.disabled=failed.has(b.dataset.addType);
    paintThumbs(true);
  }
  function closeMenu(){ $('#component-menu').hidden=true;$('#add-component').setAttribute('aria-expanded','false');$('#add-component').focus();}
  for(const option of CATALOG){
    const component=makeComponent(option.type,option.side,'catalog-'+option.type+'-'+option.side),b=button('',()=>{
      if(getState().components.length>=MAX_COMPONENTS)return toast(`最多添加 ${MAX_COMPONENTS} 个组件`);
      const c=makeComponent(option.type,option.side);selectedId=c.id;
      apply(s=>s.components=placeNewComponent(s.components,c),{assets:true});closeMenu();toast('已添加：'+option.name);
    },{'data-add-type':option.type,'data-add-side':option.side,'aria-label':'添加 '+option.name,class:'catalog-option'});
    const picture=element('span',{class:'catalog-picture'}),canvas=element('canvas');picture.append(canvas);
    b.append(picture,element('span',{},option.name));$('#component-catalog').append(b);catalogThumbs.push({component,canvas});
  }
  $('#add-component').addEventListener('click',()=>$('#component-menu').hidden?openMenu():closeMenu());
  $('#close-component-menu').addEventListener('click',closeMenu);
  $('#arrange-components').addEventListener('click',()=>apply(s=>autoArrange(s.components)));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#component-menu').hidden)closeMenu();});
  document.addEventListener('pointerdown',e=>{if(!$('#component-menu').hidden&&!e.target.closest('.component-add-wrap'))closeMenu();});
  return {sync,paint(){paintOverlay();paintThumbs();},setActive(value){active=value;paintOverlay();},closeMenu};
}
