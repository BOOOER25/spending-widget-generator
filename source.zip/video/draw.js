import {animatedSnapshot,createMotionTracks,NUMBER_SECONDS,GAIN_SECONDS} from './motion.js';
import {clamp} from './core.js';
import {drawWidget} from '../render.js';
import {TEMPLATES} from '../templates.js';
const FONT='"Microsoft YaHei","PingFang SC",system-ui,sans-serif';
const colors={pink:['#f7d3dd','#e98da8','#fff9ed'],mint:['#cce9de','#70ad9c','#fffff6'],lilac:['#ded5f1','#9e8bc4','#fffdf7']};
function text(c,value,x,y,size,color='#32333c',weight=500,max=Infinity){
  c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign='center';c.textBaseline='middle';
  let str=String(value);while(c.measureText(str).width>max&&str.length>1)str=str.slice(0,-2)+'…';c.fillText(str,x,y);
}
function rounded(c,x,y,w,h,r,fill){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();}
function cover(c,img,x,y,w,h){const k=Math.max(w/img.width,h/img.height),sw=w/k,sh=h/k;c.drawImage(img,(img.width-sw)/2,(img.height-sh)/2,sw,sh,x,y,w,h);}
function avatar(c,img,x,y,r,initial,fill){
  c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();c.fillStyle=fill;c.fillRect(x-r,y-r,r*2,r*2);
  if(img)cover(c,img,x-r,y-r,r*2,r*2);else text(c,initial.slice(0,1),x,y,22,'#fff',700);c.restore();
}
export function layout(templates){
  const medium=t=>t==='day'||t==='month';
  if(!templates.some(medium))return templates.map((t,i)=>({x:26+i*250,y:329,w:238,h:238,template:t}));
  const sizes=templates.map(t=>medium(t)?{w:484,h:484*148/322}:{w:222,h:222});
  const total=sizes[0].h+sizes[1].h+62,top=316+(540-total)/2;
  return sizes.map((r,i)=>({...r,x:(540-r.w)/2,y:top+(i?sizes[0].h+62:0),template:templates[i]}));
}
export function createRenderer(bitmaps){
  const canvases=[document.createElement('canvas'),document.createElement('canvas')];
  const previousCanvases=[document.createElement('canvas'),document.createElement('canvas')];
  let cacheKey='',cached=[],tracks=new WeakMap();
  function invalidate(){cacheKey='';tracks=new WeakMap();}
  function widgets(s,time){
    if(!tracks.has(s))tracks.set(s,createMotionTracks(s));
    const snap=animatedSnapshot(s,time,tracks.get(s)),updated=snap.sides.map(x=>x.latest).filter(Boolean).sort((a,b)=>a.at-b.at).at(-1)?.clock||'—';
    const key=JSON.stringify([s.templates,s.imageMode,s.theme,s.people,snap.sides.map(x=>[x.latest?.id,x.total,x.monthTotal,x.count,x.latestAmount,x.ratio,x.rows,x.motion.productChanging?x.motion.progress:1])]);
    // Retain the static frame cache between transactions. Only an active
    // transition redraws at video frame rate.
    if(key!==cacheKey){
      cached=canvases.map((canvas,i)=>{
        const template=s.templates[i],f=TEMPLATES[template],side=snap.sides[i],item=side.latest,person=s.people[i];
        canvas.width=f.width;canvas.height=f.height;
        const comparison={updated,...Object.fromEntries(['left','right'].map((name,j)=>{
          const person=s.people[j],x=snap.sides[j],latest=x.latest;
          return [name,{name:person.name,avatar:bitmaps.get(person.avatar),total:x.total,monthTotal:x.monthTotal,count:x.count,ratio:x.ratio,latestAmount:x.latestAmount,category:latest?.category||'暂无消费',time:latest?.clock||'—',rows:x.rows}];
        }))};
        const progress=side.motion.progress;
        const props={template,skin:i?'right':'left',theme:i?'mint':'yellow',mode:s.imageMode,avatar:bitmaps.get(person.avatar),
          image:bitmaps.get(item?.asset),cutout:bitmaps.get(item?.asset),amount:side.latestAmount,total:side.total,
          category:item?.category||'暂无消费',time:item?.clock||'—',name:item?.name||'还没有消费',
          size:(item?.scale||1)*(.91+.09*progress),zoom:1+.075*(1-progress),x:50,y:50,comparison};
        const appearance={outline:1.5,shadow:.8};
        drawWidget(canvas,props,appearance);
        if(side.motion.productChanging&&(template==='small'||template==='fake')){
          const old=side.motion.previous,previous=previousCanvases[i];
          previous.width=f.width;previous.height=f.height;
          drawWidget(previous,{...props,image:bitmaps.get(old?.asset),cutout:bitmaps.get(old?.asset),
            category:old?.category||'暂无消费',time:old?.clock||'—',name:old?.name||'还没有消费',size:old?.scale||1,zoom:1},appearance);
          const c=canvas.getContext('2d'),k=f.width/f.logicalWidth;
          c.save();c.setTransform(k,0,0,k,0,0);c.beginPath();
          // Crossfade only the product area. Artwork, avatar and text remain crisp.
          if(template==='small'){c.rect(15,27,124,77);c.rect(73,108,55,15);}
          else{c.rect(28,30,114,101);c.rect(12,128,146,15);}
          c.clip();c.globalAlpha=1-progress;
          c.drawImage(previous,0,0,f.logicalWidth,f.logicalHeight);c.restore();
        }
        return canvas;
      });cacheKey=key;
    }
    return {snap,canvases:cached};
  }
  return {invalidate,draw(canvas,s,time){
    const c=canvas.getContext('2d');c.setTransform(canvas.width/540,0,0,canvas.height/960,0,0);c.clearRect(0,0,540,960);
    const [base,accent,paper]=colors[s.theme]||colors.mint;c.fillStyle=base;c.fillRect(0,0,540,960);
    const bg=bitmaps.get(s.background);
    if(bg){cover(c,bg,0,0,540,960);c.fillStyle='#ffffff28';c.fillRect(0,0,540,960);}
    else{
      c.strokeStyle='#ffffff60';c.lineWidth=1;
      for(let x=0;x<=540;x+=24){c.beginPath();c.moveTo(x,0);c.lineTo(x,960);c.stroke();}
      for(let y=0;y<=960;y+=24){c.beginPath();c.moveTo(0,y);c.lineTo(540,y);c.stroke();}
      c.fillStyle=paper;c.beginPath();c.ellipse(270,490,241,455,0,0,Math.PI*2);c.fill();
      for(let a=0;a<Math.PI*2;a+=.055){c.fillStyle='#ffffffb8';c.beginPath();c.arc(270+242*Math.cos(a),490+455*Math.sin(a),5,0,7);c.fill();}
    }
    const {snap,canvases:images}=widgets(s,time);
    rounded(c,28,40,484,52,12,accent);text(c,s.title,270,66,21,'white',700,450);
    text(c,snap.clock,270,139,42,'#252936',800);
    rounded(c,20,183,500,94,23,'#ffffffed');
    avatar(c,bitmaps.get(s.people[0].avatar),62,229,27,s.people[0].name,accent);
    avatar(c,bitmaps.get(s.people[1].avatar),478,229,27,s.people[1].name,'#99bdac');
    // Preserve the reference comparison summary; only the changing product area becomes widgets.
    text(c,s.people[0].name,153,211,13,'#56545e',600,120);
    text(c,s.people[1].name,388,211,13,'#56545e',600,120);
    for(const [i,x] of [[0,153],[1,388]]){
      const side=snap.sides[i],pulse=side.motion.changing?Math.sin(Math.PI*clamp(side.motion.age/NUMBER_SECONDS,0,1)):0;
      text(c,'￥'+side.total.toFixed(2),x,242,26+1.4*pulse,'#e48b3e',800,145);
      if(side.motion.gain>0&&side.motion.gainOpacity>0){
        c.save();c.globalAlpha=side.motion.gainOpacity;
        text(c,'+￥'+side.motion.gain.toFixed(2),x,274-8*clamp(side.motion.age/GAIN_SECONDS,0,1),11,'#df9873',600,130);c.restore();
      }
    }
    text(c,'VS',270,232,29,'#d4c6e8',800);
    layout(s.templates).forEach((r,i)=>{
      text(c,(r.template==='day'||r.template==='month')?TEMPLATES[r.template].name:s.people[i].name,r.x+r.w/2,r.y-24,15,'#666473',600,r.w);
      const latest=snap.sides[i].latest;
      c.save();c.translate(r.x+r.w/2,r.y+r.h/2);
      c.shadowColor='#4b3f5020';c.shadowBlur=10;c.shadowOffsetY=5;c.drawImage(images[i],-r.w/2,-r.h/2,r.w,r.h);c.restore();
      const motion=snap.sides[i].motion;
      if((!latest||(motion.productChanging&&!motion.previous))&&(r.template==='small'||r.template==='fake')){
        c.save();c.globalAlpha=latest?1-motion.progress:1;
        rounded(c,r.x+r.w*.18,r.y+r.h*.30,r.w*.64,r.h*.17,8,'#fffdf5');
        text(c,'还没有消费',r.x+r.w/2,r.y+r.h*.385,12,'#a29a9a',500,r.w*.6);
        c.restore();
      }
    });
    text(c,s.footer,270,918,14,'#69606e',500,472);
  }};
}
