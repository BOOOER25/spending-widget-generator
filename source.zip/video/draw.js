import {animatedSnapshot,createMotionTracks,popPose,NUMBER_SECONDS,GAIN_SECONDS} from './motion.js';
import {clamp,hourClockAt} from './core.js';
import {sceneComponents,componentBox,isWidget,isPersonal,legacyWidgetLayout} from './components.js';
import {drawWidget} from '../render.js';
import {TEMPLATES} from '../templates.js';
const FONT='"Microsoft YaHei","PingFang SC",system-ui,sans-serif';
const colors={pink:['#f7d3dd','#e98da8','#fff9ed'],mint:['#cce9de','#70ad9c','#fffff6'],lilac:['#ded5f1','#9e8bc4','#fffdf7']};
function text(c,value,x,y,size,color='#32333c',weight=500,max=Infinity){
  c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign='center';c.textBaseline='middle';
  let str=String(value);while(c.measureText(str).width>max&&str.length>1)str=str.slice(0,-2)+'…';c.fillText(str,x,y);
}
function rounded(c,x,y,w,h,r,fill){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();}
function cover(c,img,x,y,w,h){const k=Math.max(w/img.width,h/img.height),sw=w/k,sh=h/k;c.drawImage(img,(img.width-sw)/2,(img.height-sh)/2,sw,sh,x,y,w,h);}
function avatar(c,img,x,y,r,initial,fill){
  c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();c.fillStyle=fill;c.fillRect(x-r,y-r,r*2,r*2);
  if(img)cover(c,img,x-r,y-r,r*2,r*2);else text(c,initial.slice(0,1),x,y,22,'#fff',700);c.restore();
}
export const layout=legacyWidgetLayout;
export function createRenderer(bitmaps){
  let tracks=new WeakMap(),cache=new Map(),lastSnapshot;
  function invalidate(){tracks=new WeakMap();cache.clear();lastSnapshot=null;}
  function snapshot(s,time){
    if(lastSnapshot?.state===s&&lastSnapshot.time===time)return lastSnapshot.value;
    if(!tracks.has(s))tracks.set(s,createMotionTracks(s));
    const value=animatedSnapshot(s,time,tracks.get(s));lastSnapshot={state:s,time,value};return value;
  }
  function componentImage(s,item,time,snap=snapshot(s,time)){
    const kind=item.type,style=item.style;
    const key=JSON.stringify([kind,item.side,item.showTime,item.imageMode,style,s.imageMode,s.people,
      kind==='clock'?hourClockAt(s,time):snap.sides.map(x=>[x.latest,x.total,x.monthTotal,x.count,x.latestAmount,x.ratio,x.rows,
        x.motion.productChanging?x.motion.age:1,kind==='total'&&x.motion.gainOpacity>0?x.motion.age:1])]);
    let entry=cache.get(item.id);
    if(entry?.key===key)return entry.canvas;
    const canvas=entry?.canvas||document.createElement('canvas');
    const f=TEMPLATES[kind],logical=kind==='clock'?{w:200,h:64}:kind==='total'?{w:500,h:94}:{w:f.logicalWidth,h:f.logicalHeight};
    canvas.width=f?f.width:logical.w*2;canvas.height=f?f.height:logical.h*2;
    const c=canvas.getContext('2d');c.setTransform(canvas.width/logical.w,0,0,canvas.height/logical.h,0,0);
    if(kind==='clock')text(c,hourClockAt(s,time),100,32,42,style.color,800);
    else if(kind==='total'){
      if(!style.transparent)rounded(c,0,0,500,94,94*style.corner/100,style.color+'ed');
      const accent=(colors[s.theme]||colors.mint)[1];
      avatar(c,bitmaps.get(s.people[0].avatar),42,46,27,s.people[0].name,accent);
      avatar(c,bitmaps.get(s.people[1].avatar),458,46,27,s.people[1].name,'#99bdac');
      text(c,s.people[0].name,133,28,13,'#56545e',600,120);text(c,s.people[1].name,368,28,13,'#56545e',600,120);
      for(const [i,x] of [[0,133],[1,368]]){
        const side=snap.sides[i],pulse=side.motion.changing?Math.sin(Math.PI*clamp(side.motion.age/NUMBER_SECONDS,0,1)):0;
        text(c,'￥'+side.total.toFixed(2),x,59,26+1.4*pulse,'#e48b3e',800,145);
        if(side.motion.gain>0&&side.motion.gainOpacity>0){c.save();c.globalAlpha=side.motion.gainOpacity;text(c,'+￥'+side.motion.gain.toFixed(2),x,89-8*clamp(side.motion.age/GAIN_SECONDS,0,1),11,'#df9873',600,130);c.restore();}
      }
      text(c,'VS',250,49,29,'#d4c6e8',800);
    }else{
      const i=item.side,side=snap.sides[i],latest=side.latest,person=s.people[i],old=side.motion.previous,age=side.motion.age;
      const updated=snap.sides.map(x=>x.latest).filter(Boolean).sort((a,b)=>a.at-b.at).at(-1)?.clock||'—';
      const comparison={updated,...Object.fromEntries(['left','right'].map((name,j)=>{
        const p=s.people[j],x=snap.sides[j],previous=x.motion.previous;
        return [name,{name:p.name,avatar:bitmaps.get(p.avatar),total:x.total,monthTotal:x.monthTotal,count:x.count,ratio:x.ratio,latestAmount:x.latestAmount,
          category:x.latest?.category||'暂无消费',time:x.latest?.clock||'—',rows:x.rows,contentMotion:x.latest?popPose(x.motion.age,12):undefined,
          previousLatest:previous&&x.motion.age<.14?{latestAmount:previous.amount,category:previous.category,time:previous.clock}:undefined,
          exitMotion:{y:-5*clamp(x.motion.age/.14,0,1),scale:1,alpha:1-clamp(x.motion.age/.14,0,1)}}];
      }))};
      drawWidget(canvas,{template:kind,skin:i?'right':'left',theme:style.transparent?'transparent':i?'mint':'yellow',baseColor:style.color,mode:item.imageMode==='inherit'?s.imageMode:item.imageMode,
        avatar:bitmaps.get(person.avatar),image:bitmaps.get(latest?.asset),cutout:bitmaps.get(latest?.asset),amount:side.latestAmount,total:side.total,
        category:latest?.category||'暂无消费',time:latest?.clock||'—',name:latest?.name||'还没有消费',size:latest?.scale||1,zoom:1,x:50,y:50,comparison,showTime:item.showTime,
        contentMotion:latest?popPose(age):undefined,previousContent:old&&age<.14?{image:bitmaps.get(old.asset),cutout:bitmaps.get(old.asset),amount:old.amount,category:old.category,time:old.clock,name:old.name,size:old.scale||1}:undefined,
        exitMotion:{y:-8*clamp(age/.14,0,1),scale:1,alpha:1-clamp(age/.14,0,1)}},{outline:1.5,shadow:.8,corner:style.corner/100});
      if(!latest&&isPersonal(item)){
        rounded(c,logical.w*.18,logical.h*.30,logical.w*.64,logical.h*.17,8,'#fffdf5');
        text(c,'还没有消费',logical.w/2,logical.h*.385,logical.w*.05,'#a29a9a',500,logical.w*.6);
      }
    }
    if(style.corner>0&&kind!=='clock'){
      c.save();c.setTransform(1,0,0,1,0,0);c.globalCompositeOperation='destination-in';c.beginPath();
      c.roundRect(0,0,canvas.width,canvas.height,Math.min(canvas.width,canvas.height)*style.corner/100);c.fillStyle='#fff';c.fill();c.restore();
    }
    cache.set(item.id,{key,canvas});return canvas;
  }
  return {invalidate,
    preview(canvas,s,item,time){
      const image=componentImage(s,item,time);canvas.width=image.width;canvas.height=image.height;
      canvas.getContext('2d').drawImage(image,0,0);
    },
    draw(canvas,s,time){
      const c=canvas.getContext('2d');c.setTransform(canvas.width/540,0,0,canvas.height/960,0,0);c.clearRect(0,0,540,960);
      const [base,,paper]=colors[s.theme]||colors.mint;c.fillStyle=base;c.fillRect(0,0,540,960);
      const bg=bitmaps.get(s.background);
      if(bg){cover(c,bg,0,0,540,960);c.fillStyle='#ffffff28';c.fillRect(0,0,540,960);}
      else{
        c.strokeStyle='#ffffff60';c.lineWidth=1;
        for(let x=0;x<=540;x+=24){c.beginPath();c.moveTo(x,0);c.lineTo(x,960);c.stroke();}
        for(let y=0;y<=960;y+=24){c.beginPath();c.moveTo(0,y);c.lineTo(540,y);c.stroke();}
        c.fillStyle=paper;c.beginPath();c.ellipse(270,490,241,455,0,0,Math.PI*2);c.fill();
        for(let a=0;a<Math.PI*2;a+=.055){c.fillStyle='#ffffffb8';c.beginPath();c.arc(270+242*Math.cos(a),490+455*Math.sin(a),5,0,7);c.fill();}
      }
      const snap=snapshot(s,time);
      for(const item of sceneComponents(s)){
        if(!item.visible)continue;
        const r=componentBox(item),image=componentImage(s,item,time,snap);
        if(item.showLabel)text(c,isPersonal(item)?s.people[item.side].name:COMPONENT_LABELS[item.type],r.x+r.w/2,r.y-24,15,'#666473',600,r.w);
        c.save();if(isWidget(item)){c.shadowColor='#4b3f5020';c.shadowBlur=10;c.shadowOffsetY=5;}
        c.drawImage(image,r.x,r.y,r.w,r.h);c.restore();
      }
      text(c,s.footer,270,918,14,'#69606e',500,472);
    }
  };
}
const COMPONENT_LABELS={day:'今日消费对比',month:'本月消费对比',clock:'当前时间',total:'今日消费总对比'};
