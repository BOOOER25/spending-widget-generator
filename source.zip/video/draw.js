import {snapshot,clamp} from './core.js';
import {drawWidget} from '../render.js';
import {TEMPLATES} from '../templates.js';
const FONT='"Microsoft YaHei","PingFang SC",system-ui,sans-serif';
const colors={pink:['#f7d3dd','#e98da8','#fff9ed'],mint:['#cce9de','#70ad9c','#fffff6'],lilac:['#ded5f1','#9e8bc4','#fffdf7']};
function text(c,value,x,y,size,color='#32333c',weight=500,max=Infinity){
  c.font=`${weight} ${size}px ${FONT}`;c.fillStyle=color;c.textAlign='center';c.textBaseline='middle';
  let str=String(value);while(c.measureText(str).width>max&&str.length>1)str=str.slice(0,-2)+'…';c.fillText(str,x,y);
}
function rounded(c,x,y,w,h,r,fill){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();}
function cover(c,img,x,y,w,h){const k=Math.max(w/img.width,h/img.height),sw=w/k,sh=h/k;c.drawImage(img,(img.width-sw)/2,(img.height-sh)/2,sw,sh,x,y,w,h);}
function avatar(c,img,x,y,r,initial,fill){
  c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();c.fillStyle=fill;c.fillRect(x-r,y-r,r*2,r*2);
  if(img)cover(c,img,x-r,y-r,r*2,r*2);else text(c,initial.slice(0,1),x,y,22,'#fff',700);c.restore();
}
export function layout(templates){
  const medium=t=>t==='day'||t==='month';
  if(!templates.some(medium))return templates.map((t,i)=>({x:26+i*250,y:329,w:238,h:238,template:t}));
  const sizes=templates.map(t=>medium(t)?{w:484,h:484*148/322}:{w:222,h:222});
  const total=sizes[0].h+sizes[1].h+62,top=316+(540-total)/2;
  return sizes.map((r,i)=>({...r,x:(540-r.w)/2,y:top+(i?sizes[0].h+62:0),template:templates[i]}));
}
export function createRenderer(bitmaps){
  const canvases=[document.createElement('canvas'),document.createElement('canvas')];let cacheKey='',cached=[];
  function invalidate(){cacheKey='';}
  function widgets(s,time){
    const snap=snapshot(s,time),updated=snap.sides.map(x=>x.latest).filter(Boolean).sort((a,b)=>a.at-b.at).at(-1)?.clock||'—';
    const key=JSON.stringify([s.templates,s.imageMode,s.theme,s.people,snap.sides.map(x=>[x.latest?.id,x.total,x.monthTotal,x.count])]);
    // Draw complete components only when their content changes, not every video frame.
    if(key!==cacheKey){
      cached=canvases.map((canvas,i)=>{
        const template=s.templates[i],f=TEMPLATES[template],side=snap.sides[i],item=side.latest,person=s.people[i];
        canvas.width=f.width;canvas.height=f.height;
        const comparison={updated,...Object.fromEntries(['left','right'].map((name,j)=>{
          const person=s.people[j],x=snap.sides[j],latest=x.latest;
          return [name,{name:person.name,avatar:bitmaps.get(person.avatar),total:x.total,monthTotal:x.monthTotal,count:x.count,latestAmount:latest?.amount||'0',category:latest?.category||'暂无消费',time:latest?.clock||'—',rows:x.rows}];
        }))};
        drawWidget(canvas,{template,skin:i?'right':'left',theme:i?'mint':'yellow',mode:s.imageMode,avatar:bitmaps.get(person.avatar),
          image:bitmaps.get(item?.asset),cutout:bitmaps.get(item?.asset),amount:item?.amount||'0',total:side.total,
          category:item?.category||'暂无消费',time:item?.clock||'—',name:item?.name||'还没有消费',size:item?.scale||1,zoom:1,x:50,y:50,comparison},{outline:1.5,shadow:.8});
        return canvas;
      });cacheKey=key;
    }
    return {snap,canvases:cached};
  }
  return {invalidate,draw(canvas,s,time){
    const c=canvas.getContext('2d');c.setTransform(canvas.width/540,0,0,canvas.height/960,0,0);c.clearRect(0,0,540,960);
    const [base,accent,paper]=colors[s.theme]||colors.mint;c.fillStyle=base;c.fillRect(0,0,540,960);
    const bg=bitmaps.get(s.background);
    if(bg){cover(c,bg,0,0,540,960);c.fillStyle='#ffffff28';c.fillRect(0,0,540,960);}
    else{
      c.strokeStyle='#ffffff60';c.lineWidth=1;
      for(let x=0;x<=540;x+=24){c.beginPath();c.moveTo(x,0);c.lineTo(x,960);c.stroke();}
      for(let y=0;y<=960;y+=24){c.beginPath();c.moveTo(0,y);c.lineTo(540,y);c.stroke();}
      c.fillStyle=paper;c.beginPath();c.ellipse(270,490,241,455,0,0,Math.PI*2);c.fill();
      for(let a=0;a<Math.PI*2;a+=.055){c.fillStyle='#ffffffb8';c.beginPath();c.arc(270+242*Math.cos(a),490+455*Math.sin(a),5,0,7);c.fill();}
    }
    const {snap,canvases:images}=widgets(s,time);
    rounded(c,28,40,484,52,12,accent);text(c,s.title,270,66,21,'white',700,450);
    text(c,snap.clock,270,139,42,'#252936',800);
    rounded(c,20,183,500,94,23,'#ffffffed');
    avatar(c,bitmaps.get(s.people[0].avatar),62,229,27,s.people[0].name,accent);
    avatar(c,bitmaps.get(s.people[1].avatar),478,229,27,s.people[1].name,'#99bdac');
    // Preserve the reference comparison summary; only the changing product area becomes widgets.
    text(c,s.people[0].name,153,211,13,'#56545e',600,120);
    text(c,s.people[1].name,388,211,13,'#56545e',600,120);
    text(c,'￥'+snap.sides[0].total.toFixed(2),153,242,26,'#e48b3e',800,145);
    text(c,'￥'+snap.sides[1].total.toFixed(2),388,242,26,'#e48b3e',800,145);
    text(c,'VS',270,232,29,'#d4c6e8',800);
    layout(s.templates).forEach((r,i)=>{
      text(c,(r.template==='day'||r.template==='month')?TEMPLATES[r.template].name:s.people[i].name,r.x+r.w/2,r.y-24,15,'#666473',600,r.w);
      const latest=snap.sides[i].latest,age=latest?clamp((time-latest.at)/.25,0,1):1;
      const scale=.985+.015*(1-Math.pow(1-age,3));
      c.save();c.translate(r.x+r.w/2,r.y+r.h/2);c.scale(scale,scale);
      c.shadowColor='#4b3f5020';c.shadowBlur=10;c.shadowOffsetY=5;c.drawImage(images[i],-r.w/2,-r.h/2,r.w,r.h);c.restore();
      if(!latest&&(r.template==='small'||r.template==='fake')){
        rounded(c,r.x+r.w*.18,r.y+r.h*.30,r.w*.64,r.h*.17,8,'#fffdf5');
        text(c,'还没有消费',r.x+r.w/2,r.y+r.h*.385,12,'#a29a9a',500,r.w*.6);
      }
    });
    text(c,s.footer,270,918,14,'#69606e',500,472);
  }};
}
