export const clamp=(n,lo,hi)=>Math.min(hi,Math.max(lo,n));
export const cents=n=>Math.round(Number(n)*100);
const validClock=s=>typeof s==='string'&&/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(s);
const minutes=s=>Number(s.slice(0,2))*60+Number(s.slice(3));
const clock=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(Math.floor(n%60)).padStart(2,'0')}`;
export function schedule(s){
  if(s.timelineMode!=='clock'||!s.items.length)return s;
  const times=s.items.map(x=>minutes(x.clock)),lo=Math.min(...times),hi=Math.max(...times);
  s.items.forEach((x,i)=>x.at=1+(hi===lo?0:(times[i]-lo)/(hi-lo)*(s.duration-3)));
  return s;
}
export const visibleItems=(s,time)=>s.items.filter(x=>x.at<=time+1e-7).sort((a,b)=>a.at-b.at||minutes(a.clock)-minutes(b.clock));
export function clockAt(s,time){
  if(!s.items.length)return '07:00';
  const first=Math.min(...s.items.map(x=>minutes(x.clock)));
  if(s.timelineMode==='manual')return visibleItems(s,time).at(-1)?.clock||clock(Math.max(0,first-30));
  const last=Math.max(...s.items.map(x=>minutes(x.clock)));
  const n=time<1?Math.max(0,first-30)+(first-Math.max(0,first-30))*clamp(time,0,1)
    :first+(last-first)*clamp((time-1)/(s.duration-3||1),0,1);
  return clock(Math.floor(n+1e-7));
}
export function snapshot(s,time){
  const visible=visibleItems(s,time);
  return {clock:clockAt(s,time),sides:[0,1].map(side=>{
    const items=visible.filter(x=>x.side===side),sum=items.reduce((n,x)=>n+cents(x.amount),0);
    const categories=new Map();
    if(cents(s.people[side].openingTotal)>0)categories.set('此前消费',{name:'此前消费',cents:cents(s.people[side].openingTotal),icon:'daily'});
    for(const x of items){const key=x.category||'其他',row=categories.get(key)||{name:key,cents:0,icon:x.icon||'food'};row.cents+=cents(x.amount);categories.set(key,row);}
    let rows=[...categories.values()].sort((a,b)=>b.cents-a.cents);
    if(rows.length>3)rows=[...rows.slice(0,2),{name:'其他',icon:'daily',cents:rows.slice(2).reduce((n,x)=>n+x.cents,0)}];
    while(rows.length<3)rows.push({name:'—',cents:0,icon:'daily'});
    return {items,latest:items.at(-1)||null,total:sum/100,monthTotal:(sum+cents(s.people[side].openingTotal))/100,
      count:items.length+Number(s.people[side].openingCount),rows:rows.map(r=>({name:r.name,amount:(r.cents/100).toFixed(2),icon:r.icon}))};
  })};
}
export function validate(s){
  if(!s||s.version!==1)throw new Error('不支持的项目版本');
  if(typeof s.title!=='string'||s.title.length>48||typeof s.footer!=='string'||s.footer.length>60)throw new Error('标题最多 48 字，底部文案最多 60 字');
  if(s.unit!=='元')throw new Error('小组件视频使用消费金额');
  if(!Number.isFinite(s.duration)||s.duration<4||s.duration>60)throw new Error('视频时长为 4–60 秒');
  if(!['clock','manual'].includes(s.timelineMode))throw new Error('请选择时间轴方式');
  if(!['photo','cutout'].includes(s.imageMode))throw new Error('请选择图片展示方式');
  if(!Array.isArray(s.templates)||s.templates.length!==2||s.templates.some(t=>!['fake','small','day','month'].includes(t)))throw new Error('请选择有效的小组件样式');
  if(!Array.isArray(s.people)||s.people.length!==2)throw new Error('请配置双方信息');
  const money=v=>/^\d{1,6}(\.\d{1,2})?$/.test(String(v));
  for(const p of s.people){if(typeof p.name!=='string'||!p.name.trim()||p.name.length>12)throw new Error('双方名称需为 1–12 字');if(!money(p.openingTotal)||!/^\d{1,4}$/.test(String(p.openingCount)))throw new Error('本月期初金额或笔数无效');}
  if(!Array.isArray(s.items)||s.items.length>36||[0,1].some(i=>s.items.filter(x=>x.side===i).length>18))throw new Error('每方最多 18 笔消费');
  const ids=new Set();
  for(const x of s.items){
    if(typeof x.id!=='string'||!x.id||ids.has(x.id))throw new Error('明细编号重复或缺失');ids.add(x.id);
    if(![0,1].includes(x.side))throw new Error('请选择消费归属');
    if(typeof x.name!=='string'||!x.name.trim()||x.name.length>20)throw new Error('商品名称需为 1–20 字');
    if(typeof x.category!=='string'||!x.category.trim()||x.category.length>12)throw new Error('分类需为 1–12 字');
    if(!money(x.amount))throw new Error('消费金额为 0–999999.99，最多两位小数');
    if(!validClock(x.clock))throw new Error('请填写有效的消费时间');
    if(!Number.isFinite(x.at)||x.at<0||x.at>s.duration-.5)throw new Error('出现秒数需在视频结束前至少 0.5 秒');
    if(!Number.isFinite(x.scale)||x.scale<.6||x.scale>1.4)throw new Error('图片大小超出范围');
  }
  return s;
}
export function normalize(raw){
  if(raw?.version!==1)throw new Error('不支持的项目版本');
  const text=(v,f='')=>typeof v==='string'?v:f,ref=v=>typeof v==='string'&&/^[a-zA-Z0-9_-]{1,80}$/.test(v)?v:'';
  return validate(schedule({version:1,title:text(raw.title),footer:text(raw.footer),unit:'元',duration:Number(raw.duration),
    theme:['pink','mint','lilac'].includes(raw.theme)?raw.theme:'mint',background:ref(raw.background),music:ref(raw.music),
    timelineMode:raw.timelineMode==='manual'?'manual':'clock',imageMode:raw.imageMode==='cutout'?'cutout':'photo',
    templates:Array.isArray(raw.templates)?raw.templates:['small','small'],
    people:Array.isArray(raw.people)?raw.people.map(p=>({name:text(p.name),avatar:ref(p.avatar),openingTotal:String(p.openingTotal??'0'),openingCount:String(p.openingCount??'0')})):[],
    items:Array.isArray(raw.items)?raw.items.map(x=>({id:ref(x.id),side:Number(x.side),name:text(x.name),category:text(x.category,'餐饮'),icon:['food','daily','transport'].includes(x.icon)?x.icon:'food',amount:String(x.amount),clock:text(x.clock),at:Number(x.at),asset:ref(x.asset),scale:Number(x.scale)})):[]
  }));
}
export function example(){
  const names=['早餐三明治','冰美式','午餐便当','水果酸奶','晚餐意面','小蛋糕','鲜花','奶茶'];
  return schedule({version:1,title:'当我和闺蜜共享了今日消费',footer:'认真生活，也认真记录 · 喵喵记账',unit:'元',duration:15,theme:'mint',background:'',music:'',
    timelineMode:'clock',imageMode:'photo',templates:['small','small'],
    people:[{name:'我',avatar:'',openingTotal:'0',openingCount:'0'},{name:'我的搭子',avatar:'',openingTotal:'0',openingCount:'0'}],
    items:names.map((name,i)=>({id:`sample-${i}`,side:[1,3,7].includes(i)?1:0,name,amount:String([18,12,32.5,16,42,28,35,19.9][i]),
      clock:['08:00','08:30','12:00','14:00','18:00','19:00','20:00','21:00'][i],at:0,asset:`sample-${i%4}`,scale:1,category:i===6?'日用':'餐饮',icon:i===6?'daily':'food'}))});
}
